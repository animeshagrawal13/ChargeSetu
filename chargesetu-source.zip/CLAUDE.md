# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

ChargeSetu — a peer-to-peer EV charging marketplace for **electric two-wheelers in India**.
Hosts list a home charging socket; riders find one on a map, book a slot, charge, pay per
unit, and rate each other. Built as a Smart India Hackathon 2026 prototype: it must demo
end-to-end on a real Android phone via Expo Go in under 4 minutes.

## Commands

```bash
npm start            # Expo dev server (add --tunnel if phone and PC are on different networks)
npm run android      # open on a connected Android device/emulator
npm run typecheck    # tsc --noEmit — run before every commit
npm run lint         # expo lint
```

There is no test runner wired yet; Phase 2 adds one for `compatible()` and `haversineKm()`.

## Expo version pinning

This project is on **Expo SDK 57 / React Native 0.86 / React 19.2**, which is newer than most
training data. Two consequences that have already bitten:

- `@react-navigation/*` is **not** an installed package. expo-router 57 vendors react-navigation
  internally. Derive navigator prop types from the components instead, as
  `src/components/TabBar.tsx` does with `Parameters<NonNullable<ComponentProps<typeof Tabs>['tabBar']>>[0]`.
- The default template ships `NativeTabs` from `expo-router/unstable-native-tabs`. We deliberately
  do **not** use it — the design requires a solid green filled block behind the active tab, which
  native tab bars cannot express. `src/app/(tabs)/_layout.tsx` uses the JS `Tabs` with a custom `tabBar`.

Check https://docs.expo.dev/versions/v57.0.0/ before assuming an API shape.

## Architecture

**The Repo seam is the important structural idea.** All persistence lives behind one interface
in `src/services/repo.ts`. Two implementations exist:

- `mockRepo.ts` — in-memory + AsyncStorage write-through, seeded with 10 Indore chargers and
  3 demo bookings. Needs no network, no API key, no Firebase project.
- `firebaseRepo.ts` — **currently a stub**; every method throws a descriptive error. It exists so
  the compiler enforces parity with MockRepo.

`src/config.ts → USE_MOCK` picks one, and `src/services/index.ts` exports the chosen `repo`.
**`USE_MOCK = true` must stay working at all times** — the demo runs on it. Screens import
`repo` from `@/services` and must never touch AsyncStorage or Firestore directly.

**Domain rule that is easy to get wrong.** Indian electric two-wheelers charge from household
AC sockets at 230 V. The variable is **current rating (amperes), not voltage** — never label
anything "5V". Three socket types, defined in `src/data/sockets.ts`: `SOCKET_5A` (~0.7 kW),
`SOCKET_15A` (~1.5–3.0 kW), `OEM_FAST` (~1.5–3.3 kW).

Riders carry their own portable charger, so any household socket works with any brand. Brand
only constrains `OEM_FAST`. The UX asks for brand and model because that is fast and familiar,
but `src/lib/compatibility.ts` **derives** the constraint rather than inventing one:

```
SOCKET_5A  -> always compatible (amber "Slow but works" if vehicle draws > 0.7 kW)
SOCKET_15A -> always compatible
OEM_FAST   -> charger.connectors must include vehicle.connector
```

**Power filter buckets are two-wheeler scaled** — `0.75 / 1.2 / 2.0 / 3.3 kW`. Car buckets
(3/7.2/11/22 kW) are wrong here; a household socket cannot reach them.

## Layout

```
src/
  app/            expo-router routes; (tabs)/ holds Home, Trip, Bookings, Profile
  components/     shared UI (TabBar, ChargeMap, ChargerMarker, EmptyState, ScreenHeader)
  data/           editable catalogues — vehicles, sockets, amenities, timeSlots, seedChargers
  lib/            pure helpers — compatibility, geo (haversine), format
  services/       Repo interface + MockRepo/FirebaseRepo + the USE_MOCK switch
  store/          zustand; useSession holds the signed-in user
  theme.ts        the whole design system
```

`src/data/vehicles.ts` figures are approximate and marked `// verify`. Only Ola, Ather and
Ultraviolette are marked with `OEM_*` connectors — confirm those before the demo, since every
other model defaults to a portable charger and therefore works with any household socket.

## Conventions

- Display formatting goes through `src/lib/format.ts`: distances in km to 2 decimals, money as
  `₹x.xx`, power as `x.x kW`. Do not hand-roll these.
- Style from `src/theme.ts` tokens (`colors`, `spacing`, `radius`, `type`, `card`, `shadow`).
  Card shadow opacity stays at or below 0.08. No gradients.
- Every screen needs loading, empty and error states — no infinite spinners.
- Minimum touch target 44×44 (`HIT_TARGET`), and `accessibilityLabel` on every icon-only button.
- No secrets in the repo. `.env.example` only; the Google Maps key is read from
  `process.env.EXPO_PUBLIC_GMAPS_KEY` in `app.config.ts`. Without a key `ChargeMap` sets
  `mapType="none"` and draws OpenStreetMap raster tiles via `<UrlTile>`, so the map still renders.
