import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Button from '@/components/Button';
import Dropdown from '@/components/Dropdown';
import OtpBoxes from '@/components/OtpBoxes';
import { DEFAULT_CITY } from '@/config';
import { SOCKET_ORDER, SOCKETS } from '@/data/sockets';
import { BRANDS, makeOtherVehicle, VEHICLES } from '@/data/vehicles';
import { fullChargeHours, impliedSocket } from '@/lib/compatibility';
import { formatHours, formatKw } from '@/lib/format';
import { DEMO_USER_ID, MOCK_OTP, repo } from '@/services';
import { useSession } from '@/store/useSession';
import { card, colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';
import { SocketType, Vehicle } from '@/types';

type Step = 'phone' | 'otp' | 'profile' | 'ev' | 'evDetails' | 'socket' | 'location' | 'success';

const ORDER: Step[] = ['phone', 'otp', 'profile', 'ev', 'evDetails', 'socket', 'location'];

const BATTERY_OPTIONS = [2.0, 2.2, 2.9, 3.0, 3.1, 3.24, 3.4, 3.7, 3.94, 4.0, 4.4, 5.0, 5.1, 7.1, 10.3];
const CHARGER_OPTIONS = [0.5, 0.6, 0.65, 0.7, 0.75, 0.8, 0.95, 1.0, 1.2, 1.3, 1.5];

export default function Onboarding() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const setUser = useSession((s) => s.setUser);

  const [step, setStep] = useState<Step>('phone');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [resendIn, setResendIn] = useState(0);

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [about, setAbout] = useState('');

  const [brandFilter, setBrandFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);

  const [plate, setPlate] = useState('');
  const [batteryKwh, setBatteryKwh] = useState<string | null>(null);
  const [chargerKw, setChargerKw] = useState<string | null>(null);

  const [socket, setSocket] = useState<SocketType | null>(null);

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return VEHICLES.filter(
      (v) =>
        (brandFilter === 'All' || v.brand === brandFilter) &&
        (!q || `${v.brand} ${v.model}`.toLowerCase().includes(q))
    );
  }, [brandFilter, search]);

  const stepIndex = ORDER.indexOf(step);

  const back = () => {
    setError(null);
    if (stepIndex > 0) setStep(ORDER[stepIndex - 1]);
  };

  const sendOtp = async () => {
    if (!/^\d{10}$/.test(phone)) return setError('Enter a 10-digit mobile number.');
    setError(null);
    setBusy(true);
    try {
      await repo.sendOtp(phone);
      setStep('otp');
      setResendIn(45);
      showToast('otp sent successfully');
    } finally {
      setBusy(false);
    }
  };

  const verifyOtp = async () => {
    setError(null);
    setBusy(true);
    try {
      await repo.verifyOtp(phone, otp.slice(0, 4) || otp);
      setStep('profile');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not verify that code.');
    } finally {
      setBusy(false);
    }
  };

  const pickVehicle = (v: Vehicle) => {
    setVehicle(v);
    setBatteryKwh(String(v.batteryKwh));
    setChargerKw(String(v.onboardChargerKw));
    setSocket(impliedSocket(v));
    setStep('evDetails');
  };

  const finish = async () => {
    if (!vehicle || !socket) return;
    setBusy(true);
    setError(null);
    try {
      await Location.requestForegroundPermissionsAsync().catch(() => null);
      await setUser({
        id: DEMO_USER_ID,
        name: `${firstName.trim()} ${lastName.trim()}`.trim(),
        phone,
        email: email.trim(),
        about: about.trim(),
        vehicleNumber: plate.trim().toUpperCase(),
        vehicle: {
          ...vehicle,
          batteryKwh: Number(batteryKwh ?? vehicle.batteryKwh),
          onboardChargerKw: Number(chargerKw ?? vehicle.onboardChargerKw),
        },
        preferredSocket: socket,
        role: 'rider',
        rating: 0,
        ratingsCount: 0,
        hostBadge: 'Newbie',
        createdAt: Date.now(),
      });
      setStep('success');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save your profile.');
    } finally {
      setBusy(false);
    }
  };

  const effectiveVehicle = vehicle
    ? {
        ...vehicle,
        batteryKwh: Number(batteryKwh ?? vehicle.batteryKwh),
        onboardChargerKw: Number(chargerKw ?? vehicle.onboardChargerKw),
      }
    : null;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {step !== 'success' && (
        <View style={[styles.top, { paddingTop: insets.top + spacing.md }]}>
          {stepIndex > 0 ? (
            <Pressable onPress={back} accessibilityRole="button" accessibilityLabel="Go back" style={styles.iconBtn}>
              <MaterialCommunityIcons name="chevron-left" size={28} color={colors.text} />
            </Pressable>
          ) : (
            <View style={styles.iconBtn} />
          )}
          <View style={styles.dots}>
            {ORDER.map((s, i) => (
              <View key={s} style={[styles.dot, i <= stepIndex && styles.dotOn]} />
            ))}
          </View>
        </View>
      )}

      {!!toast && (
        <View style={styles.toast}>
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      )}

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
        {step === 'phone' && (
          <>
            <Text style={type.h1}>Welcome to ChargeSetu ⚡</Text>
            <Text style={type.caption}>
              Find home charging sockets for your electric two-wheeler across {DEFAULT_CITY}.
            </Text>

            <Text style={styles.label}>
              Mobile number <Text style={styles.req}>*</Text>
            </Text>
            <View style={styles.phoneRow}>
              <View style={styles.cc}>
                <Text style={styles.ccText}>+91</Text>
              </View>
              <TextInput
                style={[styles.input, { flex: 1 }]}
                value={phone}
                onChangeText={(t) => setPhone(t.replace(/\D/g, '').slice(0, 10))}
                placeholder="10-digit number"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
              />
            </View>

            {!!error && <Text style={styles.error}>{error}</Text>}
            <Button label="Send OTP" onPress={sendOtp} loading={busy} style={{ marginTop: spacing.xl }} />
          </>
        )}

        {step === 'otp' && (
          <>
            <Text style={type.h1}>OTP Verification 🔐</Text>
            <Text style={type.caption}>
              We have sent an OTP code to phone number +91 {phone}.
            </Text>

            <View style={{ marginVertical: spacing.xxl }}>
              <OtpBoxes value={otp} onChange={setOtp} />
            </View>

            <Text style={styles.resendTitle}>Didn&apos;t receive SMS?</Text>
            {resendIn > 0 ? (
              <Text style={styles.resendText}>
                You can resend code in <Text style={styles.resendCount}>{resendIn}</Text> s
              </Text>
            ) : (
              <Pressable
                onPress={() => {
                  setResendIn(45);
                  showToast('otp sent successfully');
                }}
                accessibilityRole="button"
                accessibilityLabel="Resend code">
                <Text style={styles.resendLink}>Resend code</Text>
              </Pressable>
            )}

            <Text style={[type.caption, styles.center, { marginTop: spacing.md }]}>
              Prototype mode — enter {MOCK_OTP} followed by any two digits.
            </Text>

            {!!error && <Text style={styles.error}>{error}</Text>}
            <Button
              label="Verify OTP"
              disabled={otp.length < 4}
              loading={busy}
              onPress={verifyOtp}
              style={{ marginTop: spacing.xl }}
            />
          </>
        )}

        {step === 'profile' && (
          <>
            <View style={styles.avatarWrap}>
              <View style={styles.avatar}>
                <MaterialCommunityIcons name="account" size={48} color={colors.textMuted} />
              </View>
              <View style={styles.avatarEdit}>
                <MaterialCommunityIcons name="pencil" size={14} color={colors.white} />
              </View>
            </View>

            <View style={styles.nameRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.label}>
                  First Name <Text style={styles.req}>*</Text>
                </Text>
                <TextInput
                  style={styles.input}
                  value={firstName}
                  onChangeText={setFirstName}
                  placeholder="Animesh"
                  placeholderTextColor={colors.textMuted}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.label}>
                  Last Name <Text style={styles.req}>*</Text>
                </Text>
                <TextInput
                  style={styles.input}
                  value={lastName}
                  onChangeText={setLastName}
                  placeholder="Agrawal"
                  placeholderTextColor={colors.textMuted}
                />
              </View>
            </View>

            <Text style={styles.label}>Email ID</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              placeholder="you@example.com"
              placeholderTextColor={colors.textMuted}
              keyboardType="email-address"
              autoCapitalize="none"
            />

            <Text style={styles.label}>About Me</Text>
            <TextInput
              style={[styles.input, styles.textarea]}
              value={about}
              onChangeText={(t) => setAbout(t.slice(0, 250))}
              placeholder="Share something about you that will be visible to other EV owners"
              placeholderTextColor={colors.textMuted}
              multiline
            />
            <Text style={styles.counter}>{about.length}/250</Text>

            <Button
              label="Next"
              disabled={firstName.trim().length < 2 || lastName.trim().length < 1}
              onPress={() => setStep('ev')}
              style={{ marginTop: spacing.lg }}
            />
          </>
        )}

        {step === 'ev' && (
          <>
            <Text style={type.h1}>Select your EV</Text>

            <View style={styles.searchRow}>
              <MaterialCommunityIcons name="magnify" size={20} color={colors.textMuted} />
              <TextInput
                style={styles.searchInput}
                value={search}
                onChangeText={setSearch}
                placeholder="Search brand or model"
                placeholderTextColor={colors.textMuted}
              />
            </View>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
              {['All', ...BRANDS.filter((b) => b !== 'Other / not listed')].map((b) => {
                const on = brandFilter === b;
                return (
                  <Pressable
                    key={b}
                    onPress={() => setBrandFilter(b)}
                    accessibilityRole="button"
                    accessibilityState={{ selected: on }}
                    accessibilityLabel={b}
                    style={[styles.chip, on && styles.chipOn]}>
                    <Text style={[styles.chipText, on && styles.chipTextOn]}>{b}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>

            <View style={styles.grid}>
              {filtered.map((v) => (
                <Pressable
                  key={`${v.brand}-${v.model}`}
                  onPress={() => pickVehicle(v)}
                  accessibilityRole="button"
                  accessibilityLabel={`${v.brand} ${v.model}`}
                  style={styles.evTile}>
                  <View style={styles.evIcon}>
                    <MaterialCommunityIcons name="motorbike-electric" size={40} color={colors.primaryDark} />
                  </View>
                  <Text style={styles.evModel} numberOfLines={1}>
                    {v.model}
                  </Text>
                  <Text style={styles.evBrand} numberOfLines={1}>
                    {v.brand}
                  </Text>
                </Pressable>
              ))}
            </View>

            <Button
              label="My vehicle isn't listed"
              variant="outline"
              onPress={() => pickVehicle(makeOtherVehicle(search || 'Unlisted model'))}
              style={{ marginTop: spacing.lg }}
            />
          </>
        )}

        {step === 'evDetails' && vehicle && (
          <>
            <Text style={type.h1}>Set EV Details</Text>

            <View style={styles.evHero}>
              <MaterialCommunityIcons name="motorbike-electric" size={56} color={colors.primaryDark} />
              <Text style={styles.evHeroName}>
                {vehicle.brand} {vehicle.model}
              </Text>
            </View>

            <Text style={styles.label}>
              Enter your vehicle number <Text style={styles.req}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              value={plate}
              onChangeText={(t) => setPlate(t.toUpperCase().slice(0, 12))}
              placeholder="MP09 AB 1234"
              placeholderTextColor={colors.textMuted}
              autoCapitalize="characters"
            />

            <Dropdown
              label="Your EV Battery Capacity"
              required
              placeholder="Select battery capacity"
              value={batteryKwh}
              options={BATTERY_OPTIONS.map((b) => ({ label: `${b} kWh`, value: String(b) }))}
              onSelect={setBatteryKwh}
            />

            <Dropdown
              label="Your AC Charger kW"
              required
              placeholder="Select AC charger kW"
              value={chargerKw}
              options={CHARGER_OPTIONS.map((c) => ({ label: formatKw(c), value: String(c) }))}
              onSelect={setChargerKw}
            />

            <Button
              label="Next"
              disabled={!plate.trim() || !batteryKwh || !chargerKw}
              onPress={() => setStep('socket')}
              style={{ marginTop: spacing.xxl }}
            />
          </>
        )}

        {step === 'socket' && effectiveVehicle && (
          <>
            <Text style={type.h1}>Your charging need</Text>
            <Text style={type.caption}>
              Household sockets are rated in amperes, not volts. Pick the one you can use.
            </Text>

            {SOCKET_ORDER.map((id) => {
              const s = SOCKETS[id];
              const on = socket === id;
              return (
                <Pressable
                  key={id}
                  onPress={() => setSocket(id)}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: on }}
                  accessibilityLabel={s.label}
                  style={[styles.socketCard, on && styles.socketCardOn]}>
                  <View style={styles.socketTop}>
                    <Text style={[type.title, { flex: 1 }]}>{s.label}</Text>
                    <MaterialCommunityIcons
                      name={on ? 'radiobox-marked' : 'radiobox-blank'}
                      size={22}
                      color={on ? colors.primary : colors.border}
                    />
                  </View>
                  <Text style={type.caption}>{s.realWorld}</Text>
                  <Text style={[type.body, { marginTop: spacing.xs }]}>
                    {s.powerLabel} • full charge in {formatHours(fullChargeHours(id, effectiveVehicle))}
                  </Text>
                </Pressable>
              );
            })}

            <Button label="Next" disabled={!socket} onPress={() => setStep('location')} style={{ marginTop: spacing.xl }} />
          </>
        )}

        {step === 'location' && (
          <>
            <Text style={type.h1}>Find chargers near you</Text>
            <Text style={type.caption}>
              We use your location to sort sockets by distance. This prototype covers {DEFAULT_CITY} only.
            </Text>

            <View style={styles.cityCard}>
              <MaterialCommunityIcons name="map-marker" size={22} color={colors.primary} />
              <View style={{ flex: 1 }}>
                <Text style={type.title}>{DEFAULT_CITY}</Text>
                <Text style={type.caption}>10 host sockets listed</Text>
              </View>
            </View>

            {!!error && <Text style={styles.error}>{error}</Text>}
            <Button label="Allow location & finish" onPress={finish} loading={busy} style={{ marginTop: spacing.xl }} />
            <Button label="Skip for now" variant="outline" onPress={finish} style={{ marginTop: spacing.md }} />
          </>
        )}

        {step === 'success' && effectiveVehicle && (
          <View style={styles.successWrap}>
            <MaterialCommunityIcons name="check-decagram" size={88} color={colors.primary} />
            <Text style={[type.h1, styles.center]}>Successfully Added!</Text>

            <View style={styles.successCard}>
              <MaterialCommunityIcons name="motorbike-electric" size={48} color={colors.primaryDark} />
              <Text style={styles.evHeroName}>
                {effectiveVehicle.brand} {effectiveVehicle.model}
              </Text>
              <Text style={type.caption}>{plate.toUpperCase()}</Text>
              <Text style={type.caption}>
                Battery Capacity: {effectiveVehicle.batteryKwh} kWh • Charger{' '}
                {formatKw(effectiveVehicle.onboardChargerKw)}
              </Text>
            </View>

            <Button label="Continue" onPress={() => router.replace('/')} style={{ marginTop: spacing.xxl, alignSelf: 'stretch' }} />
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  top: {
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  iconBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  dots: { flexDirection: 'row', gap: 6, flex: 1, paddingRight: spacing.lg },
  dot: { height: 4, flex: 1, borderRadius: radius.pill, backgroundColor: colors.border },
  dotOn: { backgroundColor: colors.primary },
  toast: {
    position: 'absolute',
    bottom: 40,
    alignSelf: 'center',
    zIndex: 10,
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.xxl,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
  },
  toastText: { fontFamily: fonts.semibold, fontSize: 15, color: colors.white },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  label: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text, marginTop: spacing.lg, marginBottom: spacing.sm },
  req: { color: colors.danger },
  input: {
    minHeight: HIT_TARGET + 8,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.regular,
    fontSize: 16,
    color: colors.text,
    backgroundColor: colors.bg,
  },
  textarea: { minHeight: 110, paddingTop: spacing.md, textAlignVertical: 'top' },
  counter: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMuted, textAlign: 'right', marginTop: 4 },
  phoneRow: { flexDirection: 'row', gap: spacing.sm },
  cc: {
    minHeight: HIT_TARGET + 8,
    paddingHorizontal: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    justifyContent: 'center',
    backgroundColor: colors.surface,
  },
  ccText: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text },
  error: { fontFamily: fonts.medium, fontSize: 13, color: colors.danger, marginTop: spacing.md },
  center: { textAlign: 'center' },
  resendTitle: {
    fontFamily: fonts.semibold,
    fontSize: 15,
    color: colors.text,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
  resendText: { fontFamily: fonts.regular, fontSize: 14, color: colors.textMuted, textAlign: 'center', marginTop: 4 },
  resendCount: { fontFamily: fonts.bold, color: colors.primary },
  resendLink: { fontFamily: fonts.semibold, fontSize: 15, color: colors.primary, textAlign: 'center', marginTop: 4 },
  avatarWrap: { alignSelf: 'flex-start', marginTop: spacing.md },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarEdit: {
    position: 'absolute',
    right: 0,
    top: 4,
    width: 28,
    height: 28,
    borderRadius: radius.pill,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.bg,
  },
  nameRow: { flexDirection: 'row', gap: spacing.md },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    minHeight: HIT_TARGET + 4,
    paddingHorizontal: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    marginTop: spacing.lg,
  },
  searchInput: { flex: 1, fontFamily: fonts.regular, fontSize: 15, color: colors.text },
  chipRow: { gap: spacing.sm, paddingVertical: spacing.lg },
  chip: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontFamily: fonts.medium, fontSize: 14, color: colors.text },
  chipTextOn: { color: colors.white, fontFamily: fonts.semibold },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md },
  evTile: {
    width: '47%',
    flexGrow: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    alignItems: 'center',
    gap: 4,
  },
  evIcon: { marginBottom: spacing.sm },
  evModel: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text },
  evBrand: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMuted },
  evHero: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.xl,
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  evHeroName: { fontFamily: fonts.semibold, fontSize: 18, color: colors.text },
  socketCard: { ...card, marginTop: spacing.md, gap: 2 },
  socketCardOn: { borderColor: colors.primary, borderWidth: 2, backgroundColor: colors.primarySoft },
  socketTop: { flexDirection: 'row', alignItems: 'center' },
  cityCard: { ...card, flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.lg },
  successWrap: { alignItems: 'center', paddingTop: spacing.xxxl, gap: spacing.lg },
  successCard: {
    alignSelf: 'stretch',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.xl,
    alignItems: 'center',
    gap: 4,
  },
});
