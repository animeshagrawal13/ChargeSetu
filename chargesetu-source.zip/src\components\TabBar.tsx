import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { Tabs } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { colors, fonts, HIT_TARGET } from '@/theme';

/**
 * expo-router 57 vendors react-navigation internally, so `@react-navigation/bottom-tabs`
 * is not resolvable. Derive the prop type from the component we actually render against.
 */
type BottomTabBarProps = Parameters<
  NonNullable<React.ComponentProps<typeof Tabs>['tabBar']>
>[0];

type IconName = React.ComponentProps<typeof MaterialCommunityIcons>['name'];

const ICONS: Record<string, { active: IconName; inactive: IconName; label: string }> = {
  index: { active: 'map', inactive: 'map-outline', label: 'Home' },
  trip: { active: 'map-marker-path', inactive: 'map-marker-path', label: 'Trip' },
  bookings: { active: 'calendar-check', inactive: 'calendar-check-outline', label: 'Bookings' },
  profile: { active: 'account-circle', inactive: 'account-circle-outline', label: 'Profile' },
};

/**
 * The active tab is a solid green block with white icon and label — not a tint. That is
 * why this is a custom bar rather than the platform native tabs.
 */
export default function TabBar({ state, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.bar, { paddingBottom: insets.bottom }]}>
      {state.routes.map((route, index) => {
        const meta = ICONS[route.name];
        if (!meta) return null;

        const isActive = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });
          if (!isActive && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        return (
          <Pressable
            key={route.key}
            onPress={onPress}
            accessibilityRole="tab"
            accessibilityState={{ selected: isActive }}
            accessibilityLabel={meta.label}
            style={[styles.tab, isActive && styles.tabActive]}>
            <MaterialCommunityIcons
              name={isActive ? meta.active : meta.inactive}
              size={22}
              color={isActive ? colors.white : colors.textMuted}
            />
            <Text style={[styles.label, isActive && styles.labelActive]} numberOfLines={1}>
              {meta.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    backgroundColor: colors.bg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  tab: {
    flex: 1,
    minHeight: HIT_TARGET + 16,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    paddingVertical: 8,
  },
  tabActive: {
    backgroundColor: colors.primary,
  },
  label: {
    fontFamily: fonts.medium,
    fontSize: 12,
    color: colors.textMuted,
  },
  labelActive: {
    color: colors.white,
    fontFamily: fonts.semibold,
  },
});
