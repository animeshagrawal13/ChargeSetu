/**
 * Single switch between the two Repo implementations.
 *
 * USE_MOCK = true is the demo default and must always produce a fully working app
 * with no network, no API key and no Firebase project. Do not flip this to commit.
 */
export const USE_MOCK = true;

/** Google Maps key is optional. Without it the map falls back to OSM raster tiles. */
export const GMAPS_KEY = process.env.EXPO_PUBLIC_GMAPS_KEY ?? '';
export const HAS_GMAPS_KEY = GMAPS_KEY.length > 0;

/** Indore — the demo city, and the map fallback when location is unavailable. */
export const DEFAULT_REGION = {
  latitude: 22.7196,
  longitude: 75.8577,
  latitudeDelta: 0.08,
  longitudeDelta: 0.08,
} as const;

export const DEFAULT_CITY = 'Indore';

export const APP_VERSION = '1.0.0';
