import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { getCompatibility } from '@/lib/compatibility';
import { formatKm, formatKw, formatMoney } from '@/lib/format';
import { colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';
import { Charger, Vehicle } from '@/types';
import CompatibilityBadge from './CompatibilityBadge';

type Props = {
  charger: Charger;
  km: number;
  vehicle: Vehicle | null;
  onClose: () => void;
  onOpen: () => void;
};

/** The card shown when a marker is tapped — mirrors the reference layout. */
export default function SelectedChargerCard({ charger, km, vehicle, onClose, onOpen }: Props) {
  return (
    <Pressable onPress={onOpen} accessibilityRole="button" accessibilityLabel={`Open ${charger.title}`}>
      <View style={styles.head}>
        <Text style={[type.h2, { flex: 1 }]} numberOfLines={1}>
          {charger.title}
        </Text>
        <Pressable
          onPress={onClose}
          accessibilityRole="button"
          accessibilityLabel="Close"
          hitSlop={8}
          style={styles.close}>
          <MaterialCommunityIcons name="close" size={18} color={colors.textMuted} />
        </Pressable>
      </View>

      <Text style={type.caption}>
        {charger.city} • {formatKm(km)}
      </Text>

      <View style={styles.badgeRow}>
        <Text style={styles.hostBadge}>{charger.hostBadge}</Text>
        <MaterialCommunityIcons name="star" size={14} color={colors.warning} />
        <Text style={type.caption}>
          {charger.rating.toFixed(1)} ({charger.ratingsCount})
        </Text>
      </View>

      <View style={styles.stat}>
        <MaterialCommunityIcons name="flash" size={20} color={colors.pin} />
        <Text style={styles.statText}>{formatKw(charger.powerKw)}</Text>
      </View>

      <View style={styles.stat}>
        <MaterialCommunityIcons name="ev-plug-type2" size={20} color={colors.pin} />
        <Text style={styles.statText}>{formatMoney(charger.pricePerKwh)} per kWh</Text>
      </View>

      {vehicle && (
        <View style={{ marginTop: spacing.md }}>
          <CompatibilityBadge value={getCompatibility(charger, vehicle)} />
        </View>
      )}

      <View style={styles.cta}>
        <Text style={styles.ctaText}>View details & book</Text>
        <MaterialCommunityIcons name="chevron-right" size={20} color={colors.primaryDark} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  close: {
    width: HIT_TARGET - 12,
    height: HIT_TARGET - 12,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: spacing.xs },
  hostBadge: { fontFamily: fonts.semibold, fontSize: 13, color: colors.primaryDark },
  stat: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: spacing.md },
  statText: { fontFamily: fonts.medium, fontSize: 15, color: colors.text },
  cta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    marginTop: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
  },
  ctaText: { fontFamily: fonts.semibold, fontSize: 15, color: colors.primaryDark },
});
