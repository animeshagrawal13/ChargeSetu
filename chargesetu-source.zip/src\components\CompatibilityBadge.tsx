import { StyleSheet, Text, View } from 'react-native';

import { COMPATIBILITY_LABEL } from '@/lib/compatibility';
import { colors, fonts, radius, spacing } from '@/theme';
import { Compatibility } from '@/types';

const TONE: Record<Compatibility, { bg: string; fg: string }> = {
  COMPATIBLE: { bg: colors.primarySoft, fg: colors.primaryDark },
  SLOW_BUT_WORKS: { bg: '#FDF0D9', fg: '#8A6100' },
  NOT_COMPATIBLE: { bg: colors.surface, fg: colors.textMuted },
};

export default function CompatibilityBadge({ value }: { value: Compatibility }) {
  const tone = TONE[value];
  return (
    <View style={[styles.badge, { backgroundColor: tone.bg }]}>
      <Text style={[styles.text, { color: tone.fg }]}>{COMPATIBILITY_LABEL[value]}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: radius.pill,
  },
  text: { fontFamily: fonts.semibold, fontSize: 11 },
});
