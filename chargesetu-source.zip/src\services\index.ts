import { USE_MOCK } from '@/config';
import { firebaseRepo } from './firebaseRepo';
import { mockRepo } from './mockRepo';
import type { Repo } from './repo';

/** The one place the implementation is chosen. Import `repo` everywhere else. */
export const repo: Repo = USE_MOCK ? mockRepo : firebaseRepo;

export type { Repo } from './repo';
export { DEMO_USER_ID, MOCK_OTP } from './mockRepo';
