import { Platform, TextStyle, ViewStyle } from 'react-native';

export const colors = {
  primary: '#4CAF20', // action green — buttons, active tab, FAB
  primaryDark: '#3D8F18',
  primarySoft: '#EAF7E3',
  pin: '#1F2A6E', // map marker navy
  bg: '#FFFFFF',
  surface: '#F7F8FA',
  border: '#E6E8EB',
  text: '#111827',
  textMuted: '#6B7280',
  danger: '#D93025',
  warning: '#F5A623',
  // Derived, used for status pills and the "my location" FAB.
  info: '#1A73E8',
  white: '#FFFFFF',
} as const;

export const radius = { sm: 8, md: 12, lg: 16, pill: 999 } as const;

/** 4-based scale. `spacing(3)` === 12. Named steps cover the common cases. */
export const space = (steps: number) => steps * 4;

export const spacing = {
  xs: space(1), // 4
  sm: space(2), // 8
  md: space(3), // 12
  lg: space(4), // 16
  xl: space(5), // 20
  xxl: space(6), // 24
  xxxl: space(8), // 32
} as const;

/**
 * Poppins is loaded in the root layout. Weights map to font families rather than
 * fontWeight, because on Android fontWeight does not select a loaded family.
 */
export const fonts = {
  regular: 'Poppins_400Regular',
  medium: 'Poppins_500Medium',
  semibold: 'Poppins_600SemiBold',
  bold: 'Poppins_700Bold',
} as const;

export const type = {
  h1: { fontFamily: fonts.semibold, fontSize: 28, lineHeight: 36, color: colors.text },
  h2: { fontFamily: fonts.semibold, fontSize: 22, lineHeight: 30, color: colors.text },
  title: { fontFamily: fonts.semibold, fontSize: 18, lineHeight: 26, color: colors.text },
  body: { fontFamily: fonts.regular, fontSize: 15, lineHeight: 22, color: colors.text },
  caption: { fontFamily: fonts.regular, fontSize: 13, lineHeight: 18, color: colors.textMuted },
} satisfies Record<string, TextStyle>;

/** Shadow opacity stays at or below 0.08 per the design system. */
export const shadow = (elevation = 2): ViewStyle =>
  Platform.select<ViewStyle>({
    android: { elevation },
    default: {
      shadowColor: '#000',
      shadowOpacity: 0.08,
      shadowRadius: elevation * 3,
      shadowOffset: { width: 0, height: elevation },
    },
  })!;

export const card: ViewStyle = {
  backgroundColor: colors.bg,
  borderRadius: radius.lg,
  borderWidth: 1,
  borderColor: colors.border,
  padding: spacing.lg,
  ...shadow(2),
};

/** Minimum touch target, per the accessibility non-negotiable. */
export const HIT_TARGET = 44;
