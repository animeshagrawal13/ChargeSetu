import { create } from 'zustand';

import { repo } from '@/services';
import { User } from '@/types';

type SessionState = {
  user: User | null;
  /** null while we are still reading persisted state on cold start. */
  status: 'loading' | 'signed-out' | 'signed-in';
  error: string | null;

  hydrate: () => Promise<void>;
  setUser: (user: User) => Promise<void>;
  patchUser: (patch: Partial<User>) => Promise<void>;
  signOut: () => Promise<void>;
};

export const useSession = create<SessionState>((set, get) => ({
  user: null,
  status: 'loading',
  error: null,

  /** Called once from the root layout. Decides onboarding vs. tabs. */
  hydrate: async () => {
    try {
      const id = await repo.getCurrentUserId();
      const user = id ? await repo.getUser(id) : null;
      set({ user, status: user ? 'signed-in' : 'signed-out', error: null });
    } catch (e) {
      set({
        user: null,
        status: 'signed-out',
        error: e instanceof Error ? e.message : 'Could not restore your session.',
      });
    }
  },

  setUser: async (user) => {
    const saved = await repo.saveUser(user);
    set({ user: saved, status: 'signed-in', error: null });
  },

  patchUser: async (patch) => {
    const current = get().user;
    if (!current) return;
    const updated = await repo.updateUser(current.id, patch);
    set({ user: updated });
  },

  signOut: async () => {
    await repo.signOut();
    set({ user: null, status: 'signed-out' });
  },
}));
