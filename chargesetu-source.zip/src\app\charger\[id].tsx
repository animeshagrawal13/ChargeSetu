import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { addDays, format, isSameDay, startOfDay } from 'date-fns';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Button from '@/components/Button';
import CompatibilityBadge from '@/components/CompatibilityBadge';
import EmptyState from '@/components/EmptyState';
import { AMENITY_BY_ID } from '@/data/amenities';
import { SOCKETS } from '@/data/sockets';
import { DAY_LABELS, SLOT_BY_ID, TIME_SLOTS } from '@/data/timeSlots';
import { getCompatibility } from '@/lib/compatibility';
import { formatDuration, formatKm, formatKw, formatKwh, formatMoney, formatRate } from '@/lib/format';
import { haversineKm } from '@/lib/geo';
import { DEFAULT_REGION } from '@/config';
import { DEMO_USER_ID, repo } from '@/services';
import { useSession } from '@/store/useSession';
import { card, colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';
import { Charger, TimeSlotId } from '@/types';

const ORIGIN = { lat: DEFAULT_REGION.latitude, lng: DEFAULT_REGION.longitude };

export default function ChargerDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const user = useSession((s) => s.user);

  const [charger, setCharger] = useState<Charger | null | 'missing'>(null);
  const [dayOffset, setDayOffset] = useState(0);
  const [slot, setSlot] = useState<TimeSlotId | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    repo
      .getCharger(String(id))
      .then((c) => setCharger(c ?? 'missing'))
      .catch(() => setCharger('missing'));
  }, [id]);

  const days = useMemo(
    () => Array.from({ length: 7 }, (_, i) => addDays(startOfDay(new Date()), i)),
    []
  );

  const offeredSlots = useMemo(() => {
    if (!charger || charger === 'missing') return new Set<TimeSlotId>();
    const weekday = days[dayOffset].getDay();
    const entry = charger.availability.find((a) => a.day === weekday);
    return new Set(entry?.slots ?? []);
  }, [charger, days, dayOffset]);

  const estimate = useMemo(() => {
    if (!charger || charger === 'missing' || !user) return null;
    const units = Math.min(user.vehicle.batteryKwh, user.vehicle.batteryKwh * 0.8);
    const kw = Math.min(charger.powerKw, user.vehicle.onboardChargerKw);
    return {
      units,
      cost: units * charger.pricePerKwh,
      minutes: kw > 0 ? (units / kw) * 60 : 0,
    };
  }, [charger, user]);

  if (charger === null) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (charger === 'missing') {
    return (
      <EmptyState
        icon="alert-circle-outline"
        title="Charger not found"
        message="It may have been removed by the host."
        actionLabel="Go back"
        onAction={() => router.back()}
      />
    );
  }

  const km = haversineKm(ORIGIN, charger.geo);

  const request = async () => {
    if (!slot || !user) return;
    setBusy(true);
    try {
      const s = SLOT_BY_ID[slot];
      const start = new Date(days[dayOffset]);
      start.setHours(s.startHour, 0, 0, 0);
      const end = new Date(start);
      // NIGHT wraps past midnight, so its end lands on the next day.
      end.setHours(s.endHour <= s.startHour ? s.endHour + 24 : s.endHour, 0, 0, 0);

      const booking = await repo.createBooking({
        chargerId: charger.id,
        riderId: user.id ?? DEMO_USER_ID,
        hostId: charger.hostId,
        slotStart: start.getTime(),
        slotEnd: end.getTime(),
        estimatedKwh: estimate?.units ?? 0,
      });
      router.replace(`/booking/${booking.id}`);
    } catch (e) {
      Alert.alert('Could not book', e instanceof Error ? e.message : 'Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} accessibilityRole="button" accessibilityLabel="Go back" style={styles.iconBtn}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
        </Pressable>
        <Text style={[type.title, { flex: 1 }]} numberOfLines={1}>
          {charger.title}
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.body}>
        <View style={styles.photo}>
          <MaterialCommunityIcons name="ev-plug-type2" size={48} color={colors.primary} />
          <Text style={type.caption}>Host photo coming soon</Text>
        </View>

        <View style={styles.rowBetween}>
          <View style={{ flex: 1 }}>
            <Text style={type.h2}>{charger.title}</Text>
            <Text style={type.caption}>
              {charger.addressLine} • {charger.landmark}
            </Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.rate}>{formatRate(charger.pricePerKwh)}</Text>
            <Text style={type.caption}>{formatKm(km)} away</Text>
          </View>
        </View>

        <View style={styles.inline}>
          <MaterialCommunityIcons name="account-circle-outline" size={18} color={colors.textMuted} />
          <Text style={type.body}>{charger.hostName}</Text>
          <MaterialCommunityIcons name="star" size={16} color={colors.warning} />
          <Text style={type.body}>
            {charger.rating.toFixed(1)} ({charger.ratingsCount})
          </Text>
          <Text style={styles.hostBadge}>{charger.hostBadge}</Text>
        </View>

        <View style={styles.socketBox}>
          <View style={{ flex: 1 }}>
            <Text style={type.title}>{SOCKETS[charger.socketType].label}</Text>
            <Text style={type.caption}>{SOCKETS[charger.socketType].realWorld}</Text>
            <Text style={[type.body, { marginTop: spacing.xs }]}>{formatKw(charger.powerKw)}</Text>
          </View>
          {user && <CompatibilityBadge value={getCompatibility(charger, user.vehicle)} />}
        </View>

        <Text style={styles.section}>Amenities</Text>
        <View style={styles.chips}>
          {charger.amenities.map((a) => (
            <View key={a} style={styles.chip}>
              <MaterialCommunityIcons name={AMENITY_BY_ID[a].icon as never} size={16} color={colors.primaryDark} />
              <Text style={styles.chipText}>{AMENITY_BY_ID[a].label}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.section}>Pick a day</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.dayStrip}>
          {days.map((d, i) => {
            const on = i === dayOffset;
            return (
              <Pressable
                key={d.toISOString()}
                onPress={() => {
                  setDayOffset(i);
                  setSlot(null);
                }}
                accessibilityRole="button"
                accessibilityLabel={format(d, 'EEEE d MMMM')}
                style={[styles.day, on && styles.dayOn]}>
                <Text style={[styles.dayName, on && { color: colors.white }]}>
                  {DAY_LABELS[d.getDay()]}
                </Text>
                <Text style={[styles.dayNum, on && { color: colors.white }]}>{format(d, 'd')}</Text>
                {isSameDay(d, new Date()) && <Text style={[styles.today, on && { color: colors.white }]}>today</Text>}
              </Pressable>
            );
          })}
        </ScrollView>

        <Text style={styles.section}>Pick a time slot</Text>
        <View style={styles.chips}>
          {TIME_SLOTS.map((s) => {
            const available = offeredSlots.has(s.id);
            const on = slot === s.id;
            return (
              <Pressable
                key={s.id}
                disabled={!available}
                onPress={() => setSlot(s.id)}
                accessibilityRole="button"
                accessibilityState={{ disabled: !available, selected: on }}
                accessibilityLabel={`${s.label} ${s.range}${available ? '' : ', unavailable'}`}
                style={[styles.slot, on && styles.slotOn, !available && styles.slotOff]}>
                <Text style={[styles.slotText, on && { color: colors.white }, !available && styles.slotTextOff]}>
                  {s.label}
                </Text>
                <Text style={[type.caption, on && { color: colors.white }, !available && styles.slotTextOff]}>
                  {s.range}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {estimate && (
          <View style={styles.estimate}>
            <Text style={type.title}>Estimate</Text>
            <View style={styles.estRow}>
              <Text style={type.body}>Units needed</Text>
              <Text style={styles.estVal}>{formatKwh(estimate.units)}</Text>
            </View>
            <View style={styles.estRow}>
              <Text style={type.body}>Estimated cost</Text>
              <Text style={styles.estVal}>{formatMoney(estimate.cost)}</Text>
            </View>
            <View style={styles.estRow}>
              <Text style={type.body}>Estimated time</Text>
              <Text style={styles.estVal}>{formatDuration(estimate.minutes)}</Text>
            </View>
          </View>
        )}

        <Pressable accessibilityRole="link" accessibilityLabel="Report this listing">
          <Text style={styles.report}>Report this listing</Text>
        </Pressable>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + spacing.md }]}>
        <Button
          label={slot ? 'Request booking' : 'Pick a slot to continue'}
          disabled={!slot}
          loading={busy}
          onPress={request}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl, gap: spacing.sm },
  photo: {
    height: 160,
    borderRadius: radius.lg,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  rowBetween: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md },
  rate: { fontFamily: fonts.bold, fontSize: 18, color: colors.text },
  inline: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: spacing.sm },
  hostBadge: { fontFamily: fonts.semibold, fontSize: 13, color: colors.primaryDark },
  socketBox: { ...card, flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.lg },
  section: { fontFamily: fonts.semibold, fontSize: 17, color: colors.text, marginTop: spacing.xl },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.sm },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    backgroundColor: colors.primarySoft,
  },
  chipText: { fontFamily: fonts.medium, fontSize: 12, color: colors.primaryDark },
  dayStrip: { gap: spacing.sm, paddingVertical: spacing.sm },
  day: {
    width: 56,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  dayOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  dayName: { fontFamily: fonts.medium, fontSize: 12, color: colors.textMuted },
  dayNum: { fontFamily: fonts.semibold, fontSize: 18, color: colors.text },
  today: { fontFamily: fonts.regular, fontSize: 10, color: colors.textMuted },
  slot: {
    minWidth: '47%',
    flexGrow: 1,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  slotOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  slotOff: { backgroundColor: colors.surface, opacity: 0.6 },
  slotText: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
  slotTextOff: { textDecorationLine: 'line-through', color: colors.textMuted },
  estimate: { ...card, marginTop: spacing.xl, gap: spacing.sm },
  estRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  estVal: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
  report: {
    fontFamily: fonts.medium,
    fontSize: 13,
    color: colors.textMuted,
    textDecorationLine: 'underline',
    marginTop: spacing.xl,
  },
  footer: {
    padding: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.bg,
  },
});
