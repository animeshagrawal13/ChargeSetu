import { create } from 'zustand';

import { POWER_BUCKETS } from '@/data/sockets';
import { getCompatibility } from '@/lib/compatibility';
import { haversineKm, LatLng } from '@/lib/geo';
import { AmenityId, Charger, SocketType, TimeSlotId, Vehicle } from '@/types';

export type Filters = {
  maxKm: number;
  maxPrice: number;
  powers: number[];
  sockets: SocketType[];
  compatibleOnly: boolean;
  minRating: number;
  slots: TimeSlotId[];
  amenities: AmenityId[];
};

export const DEFAULT_FILTERS: Filters = {
  maxKm: 10,
  maxPrice: 20,
  powers: [],
  sockets: [],
  compatibleOnly: true,
  minRating: 0,
  slots: [],
  amenities: [],
};

type FiltersState = Filters & {
  set: (patch: Partial<Filters>) => void;
  reset: () => void;
  toggle: <K extends 'powers' | 'sockets' | 'slots' | 'amenities'>(
    key: K,
    value: Filters[K][number]
  ) => void;
};

export const useFilters = create<FiltersState>((set) => ({
  ...DEFAULT_FILTERS,
  set: (patch) => set(patch),
  reset: () => set({ ...DEFAULT_FILTERS }),
  toggle: (key, value) =>
    set((s) => {
      const list = s[key] as unknown[];
      return {
        [key]: list.includes(value) ? list.filter((v) => v !== value) : [...list, value],
      } as Partial<FiltersState>;
    }),
}));

/** A charger's power counts as matching a bucket if it is within 0.3 kW of it. */
const matchesPower = (powerKw: number, buckets: number[]) =>
  buckets.length === 0 || buckets.some((b) => Math.abs(powerKw - b) <= 0.3);

export type ScoredCharger = { charger: Charger; km: number };

/** Single place the filter rules are applied, so map and list can never disagree. */
export function applyFilters(
  chargers: Charger[],
  origin: LatLng,
  vehicle: Vehicle | null,
  f: Filters,
  query = ''
): ScoredCharger[] {
  const q = query.trim().toLowerCase();

  return chargers
    .map((charger) => ({ charger, km: haversineKm(origin, charger.geo) }))
    .filter(({ charger, km }) => {
      if (km > f.maxKm) return false;
      if (charger.pricePerKwh > f.maxPrice) return false;
      if (!matchesPower(charger.powerKw, f.powers)) return false;
      if (f.sockets.length && !f.sockets.includes(charger.socketType)) return false;
      if (charger.rating < f.minRating) return false;

      if (f.slots.length) {
        const offered = new Set(charger.availability.flatMap((a) => a.slots));
        if (!f.slots.some((s) => offered.has(s))) return false;
      }

      if (f.amenities.length && !f.amenities.every((a) => charger.amenities.includes(a))) {
        return false;
      }

      if (f.compatibleOnly && vehicle) {
        if (getCompatibility(charger, vehicle) === 'NOT_COMPATIBLE') return false;
      }

      if (q) {
        const haystack =
          `${charger.title} ${charger.city} ${charger.addressLine} ${charger.landmark}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }

      return true;
    })
    .sort((a, b) => a.km - b.km);
}

export { POWER_BUCKETS };
