import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import Slider from '@react-native-community/slider';
import { Modal, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AMENITIES } from '@/data/amenities';
import { POWER_BUCKETS, SOCKET_ORDER, SOCKETS } from '@/data/sockets';
import { TIME_SLOTS } from '@/data/timeSlots';
import { formatKw } from '@/lib/format';
import { useFilters } from '@/store/useFilters';
import { colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';
import Button from './Button';

type Props = {
  visible: boolean;
  matchCount: number;
  onClose: () => void;
};

export default function FiltersSheet({ visible, matchCount, onClose }: Props) {
  const insets = useSafeAreaInsets();
  const f = useFilters();

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={[styles.sheet, { paddingTop: insets.top + spacing.md }]}>
          <View style={styles.header}>
            <Text style={[type.h2, { flex: 1 }]}>Filters</Text>
            <Pressable onPress={onClose} accessibilityRole="button" accessibilityLabel="Close filters" style={styles.close}>
              <MaterialCommunityIcons name="close" size={24} color={colors.text} />
            </Pressable>
          </View>

          <ScrollView contentContainerStyle={styles.body}>
            <Text style={styles.section}>Distance</Text>
            <Text style={type.caption}>0 – {f.maxKm.toFixed(0)} km</Text>
            <Slider
              minimumValue={1}
              maximumValue={50}
              step={1}
              value={f.maxKm}
              onValueChange={(v) => f.set({ maxKm: v })}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />

            <Text style={styles.section}>Price range</Text>
            <Text style={type.caption}>₹0 – ₹{f.maxPrice.toFixed(0)} per kWh</Text>
            <Slider
              minimumValue={1}
              maximumValue={20}
              step={1}
              value={f.maxPrice}
              onValueChange={(v) => f.set({ maxPrice: v })}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />

            <Text style={styles.section}>Charging power</Text>
            <View style={styles.wrapRow}>
              {POWER_BUCKETS.map((p) => {
                const on = f.powers.includes(p);
                return (
                  <Pressable
                    key={p}
                    onPress={() => f.toggle('powers', p)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: on }}
                    accessibilityLabel={formatKw(p)}
                    style={styles.check}>
                    <MaterialCommunityIcons
                      name={on ? 'checkbox-marked' : 'checkbox-blank-outline'}
                      size={22}
                      color={on ? colors.primary : colors.border}
                    />
                    <Text style={type.body}>{formatKw(p)}</Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={styles.section}>Socket type</Text>
            {SOCKET_ORDER.map((id) => {
              const on = f.sockets.includes(id);
              return (
                <Pressable
                  key={id}
                  onPress={() => f.toggle('sockets', id)}
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: on }}
                  accessibilityLabel={SOCKETS[id].label}
                  style={styles.check}>
                  <MaterialCommunityIcons
                    name={on ? 'checkbox-marked' : 'checkbox-blank-outline'}
                    size={22}
                    color={on ? colors.primary : colors.border}
                  />
                  <Text style={type.body}>{SOCKETS[id].label}</Text>
                </Pressable>
              );
            })}

            <View style={styles.switchRow}>
              <Text style={[type.body, { flex: 1 }]}>Compatible with my vehicle only</Text>
              <Switch
                value={f.compatibleOnly}
                onValueChange={(v) => f.set({ compatibleOnly: v })}
                trackColor={{ true: colors.primary, false: colors.border }}
                thumbColor={colors.white}
              />
            </View>

            <Text style={styles.section}>Minimum rating</Text>
            <Text style={type.caption}>
              {f.minRating === 0 ? 'Any rating' : `${f.minRating.toFixed(1)}+`}
            </Text>
            <Slider
              minimumValue={0}
              maximumValue={4.5}
              step={0.5}
              value={f.minRating}
              onValueChange={(v) => f.set({ minRating: v })}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />

            <Text style={styles.section}>Available time slots</Text>
            <View style={styles.slotGrid}>
              {TIME_SLOTS.map((s) => {
                const on = f.slots.includes(s.id);
                return (
                  <Pressable
                    key={s.id}
                    onPress={() => f.toggle('slots', s.id)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: on }}
                    accessibilityLabel={`${s.label} ${s.range}`}
                    style={[styles.slotCard, on && styles.slotCardOn]}>
                    <MaterialCommunityIcons
                      name={s.icon as never}
                      size={20}
                      color={on ? colors.primaryDark : colors.textMuted}
                    />
                    <Text style={styles.slotLabel}>{s.label}</Text>
                    <Text style={type.caption}>{s.range}</Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={styles.section}>Amenities</Text>
            <View style={styles.wrapRow}>
              {AMENITIES.map((a) => {
                const on = f.amenities.includes(a.id);
                return (
                  <Pressable
                    key={a.id}
                    onPress={() => f.toggle('amenities', a.id)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: on }}
                    accessibilityLabel={a.label}
                    style={[styles.chip, on && styles.chipOn]}>
                    <MaterialCommunityIcons
                      name={a.icon as never}
                      size={18}
                      color={on ? colors.primaryDark : colors.textMuted}
                    />
                    <Text style={[styles.chipText, on && { color: colors.primaryDark }]}>
                      {a.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </ScrollView>

          <View style={[styles.footer, { paddingBottom: insets.bottom + spacing.md }]}>
            <Button label="Reset" variant="outline" onPress={f.reset} style={{ flex: 1 }} />
            <Button
              label={`Apply Filters (${matchCount})`}
              onPress={onClose}
              style={{ flex: 2 }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)' },
  sheet: { flex: 1, marginTop: 40, backgroundColor: colors.bg, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  close: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  section: { fontFamily: fonts.semibold, fontSize: 17, color: colors.text, marginTop: spacing.xl },
  wrapRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.sm },
  check: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, minHeight: HIT_TARGET, minWidth: 120 },
  switchRow: { flexDirection: 'row', alignItems: 'center', minHeight: HIT_TARGET, marginTop: spacing.lg },
  slotGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md, marginTop: spacing.sm },
  slotCard: {
    width: '47%',
    alignItems: 'center',
    gap: 2,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  slotCardOn: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  slotLabel: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  chipOn: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  chipText: { fontFamily: fonts.medium, fontSize: 12, color: colors.textMuted },
  footer: {
    flexDirection: 'row',
    gap: spacing.md,
    padding: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.bg,
  },
});
