import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, fonts, HIT_TARGET, radius, spacing } from '@/theme';

type Props = {
  label: string;
  placeholder: string;
  value: string | null;
  options: { label: string; value: string }[];
  onSelect: (value: string) => void;
  required?: boolean;
};

/** Inline expanding select — matches the reference "Set EV Details" dropdowns. */
export default function Dropdown({
  label,
  placeholder,
  value,
  options,
  onSelect,
  required,
}: Props) {
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.value === value);

  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>
        {label} {required && <Text style={styles.required}>*</Text>}
      </Text>

      <Pressable
        onPress={() => setOpen((o) => !o)}
        accessibilityRole="button"
        accessibilityLabel={`${label}. ${selected?.label ?? placeholder}`}
        accessibilityState={{ expanded: open }}
        style={[styles.field, open && styles.fieldOpen]}>
        <Text style={[styles.value, !selected && styles.placeholder]}>
          {selected?.label ?? placeholder}
        </Text>
        <MaterialCommunityIcons
          name={open ? 'chevron-up' : 'chevron-down'}
          size={22}
          color={colors.textMuted}
        />
      </Pressable>

      {open && (
        <View style={styles.menu}>
          {options.map((o, i) => (
            <Pressable
              key={o.value}
              onPress={() => {
                onSelect(o.value);
                setOpen(false);
              }}
              accessibilityRole="button"
              accessibilityLabel={o.label}
              style={[styles.option, i > 0 && styles.optionDivider]}>
              <Text style={styles.optionText}>{o.label}</Text>
              {o.value === value && (
                <MaterialCommunityIcons name="check" size={20} color={colors.primary} />
              )}
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { marginTop: spacing.lg },
  label: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text, marginBottom: spacing.sm },
  required: { color: colors.danger },
  field: {
    minHeight: HIT_TARGET + 8,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    backgroundColor: colors.bg,
  },
  fieldOpen: { borderColor: colors.primary, borderWidth: 2 },
  value: { flex: 1, fontFamily: fonts.regular, fontSize: 16, color: colors.text },
  placeholder: { color: colors.textMuted },
  menu: {
    marginTop: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    backgroundColor: colors.bg,
    overflow: 'hidden',
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: HIT_TARGET + 4,
    paddingHorizontal: spacing.lg,
  },
  optionDivider: { borderTopWidth: 1, borderTopColor: colors.border },
  optionText: { flex: 1, fontFamily: fonts.regular, fontSize: 16, color: colors.text },
});
