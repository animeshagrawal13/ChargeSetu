import { Booking, BookingStatus, Charger, Rating, User } from '@/types';

export type NewCharger = Omit<
  Charger,
  'id' | 'createdAt' | 'rating' | 'ratingsCount' | 'isActive'
>;

export type NewBooking = Pick<
  Booking,
  'chargerId' | 'riderId' | 'hostId' | 'slotStart' | 'slotEnd' | 'estimatedKwh'
>;

export type NewRating = Omit<Rating, 'id' | 'createdAt'>;

export type OtpResult = { userId: string; isNewUser: boolean };

/**
 * The single seam between the app and its backend.
 *
 * Two implementations ship: MockRepo (in-memory + AsyncStorage, seeded, no network) and
 * FirebaseRepo (phone OTP + Firestore). `USE_MOCK` in src/config.ts picks one. Screens
 * must talk to this interface only — never to AsyncStorage or Firestore directly.
 */
export interface Repo {
  // ---- auth ----
  sendOtp(phone: string): Promise<void>;
  verifyOtp(phone: string, code: string): Promise<OtpResult>;
  signOut(): Promise<void>;
  getCurrentUserId(): Promise<string | null>;

  // ---- users ----
  getUser(id: string): Promise<User | null>;
  saveUser(user: User): Promise<User>;
  updateUser(id: string, patch: Partial<User>): Promise<User>;
  deleteUser(id: string): Promise<void>;

  // ---- chargers ----
  listChargers(): Promise<Charger[]>;
  getCharger(id: string): Promise<Charger | null>;
  listChargersByHost(hostId: string): Promise<Charger[]>;
  createCharger(input: NewCharger): Promise<Charger>;
  updateCharger(id: string, patch: Partial<Charger>): Promise<Charger>;

  // ---- bookings ----
  getBooking(id: string): Promise<Booking | null>;
  listBookingsForRider(riderId: string): Promise<Booking[]>;
  listBookingsForHost(hostId: string): Promise<Booking[]>;
  createBooking(input: NewBooking): Promise<Booking>;
  setBookingStatus(
    id: string,
    status: BookingStatus,
    patch?: Partial<Booking>
  ): Promise<Booking>;

  // ---- ratings ----
  createRating(input: NewRating): Promise<Rating>;
  listRatingsForUser(userId: string): Promise<Rating[]>;

  /** Restores the seeded demo state. Wired to the hidden reset in Profile. */
  resetDemoData(): Promise<void>;
}
