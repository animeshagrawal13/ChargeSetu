import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { getCompatibility } from '@/lib/compatibility';
import { formatKm, formatKw, formatRate } from '@/lib/format';
import { card, colors, fonts, spacing, type } from '@/theme';
import { Charger, Vehicle } from '@/types';
import CompatibilityBadge from './CompatibilityBadge';

type Props = {
  charger: Charger;
  km: number;
  vehicle: Vehicle | null;
  onPress?: () => void;
  flat?: boolean;
};

export default function ChargerCard({ charger, km, vehicle, onPress, flat }: Props) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${charger.title}, ${formatKm(km)} away`}
      style={[flat ? styles.flat : styles.card]}>
      <View style={styles.row}>
        <Text style={[type.title, { flex: 1 }]} numberOfLines={1}>
          {charger.title}
        </Text>
        <View style={styles.inline}>
          <MaterialCommunityIcons name="map-marker-outline" size={14} color={colors.textMuted} />
          <Text style={type.caption}>{formatKm(km)}</Text>
        </View>
      </View>

      <View style={styles.inline}>
        <Text style={type.caption}>{charger.city}</Text>
        <Text style={type.caption}>•</Text>
        <MaterialCommunityIcons name="star" size={13} color={colors.warning} />
        <Text style={type.caption}>
          {charger.rating.toFixed(1)} ({charger.ratingsCount})
        </Text>
        <Text style={type.caption}>•</Text>
        <Text style={styles.badgeText}>{charger.hostBadge}</Text>
      </View>

      <View style={[styles.row, { marginTop: spacing.xs }]}>
        <View style={styles.inline}>
          <MaterialCommunityIcons name="flash" size={16} color={colors.pin} />
          <Text style={type.body}>{formatKw(charger.powerKw)}</Text>
        </View>
        <Text style={styles.rate}>{formatRate(charger.pricePerKwh)}</Text>
      </View>

      {vehicle && (
        <View style={{ marginTop: spacing.sm }}>
          <CompatibilityBadge value={getCompatibility(charger, vehicle)} />
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { ...card, gap: 2 },
  flat: {
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 2,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  inline: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  badgeText: { fontFamily: fonts.semibold, fontSize: 13, color: colors.primaryDark },
  rate: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
});
