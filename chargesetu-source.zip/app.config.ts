import type { ExpoConfig } from 'expo/config';

/**
 * The Google Maps key is read from the environment, never committed. Without it the app
 * still runs: the map falls back to OpenStreetMap raster tiles (see components/ChargeMap).
 */
const gmapsKey = process.env.EXPO_PUBLIC_GMAPS_KEY ?? '';

const config: ExpoConfig = {
  name: 'ChargeSetu',
  slug: 'chargesetu',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/images/icon.png',
  scheme: 'chargesetu',
  userInterfaceStyle: 'light',
  android: {
    package: 'com.chargesetu.app',
    adaptiveIcon: {
      backgroundColor: '#EAF7E3',
      foregroundImage: './assets/images/android-icon-foreground.png',
      backgroundImage: './assets/images/android-icon-background.png',
      monochromeImage: './assets/images/android-icon-monochrome.png',
    },
    predictiveBackGestureEnabled: false,
    permissions: ['ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION'],
    ...(gmapsKey ? { config: { googleMaps: { apiKey: gmapsKey } } } : {}),
  },
  ios: {
    bundleIdentifier: 'com.chargesetu.app',
    supportsTablet: true,
  },
  web: { output: 'static', favicon: './assets/images/favicon.png' },
  plugins: [
    'expo-router',
    [
      'expo-splash-screen',
      {
        backgroundColor: '#FFFFFF',
        image: './assets/images/splash-icon.png',
        imageWidth: 96,
      },
    ],
    [
      'expo-location',
      {
        locationAlwaysAndWhenInUsePermission:
          'ChargeSetu uses your location to show charging sockets near you.',
      },
    ],
    [
      'expo-image-picker',
      {
        photosPermission: 'ChargeSetu needs photo access so hosts can add pictures of their charging spot.',
      },
    ],
  ],
  experiments: { typedRoutes: false, reactCompiler: true },
  extra: { hasGmapsKey: gmapsKey.length > 0 },
};

export default config;
