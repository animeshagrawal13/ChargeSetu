import { Redirect, Tabs } from 'expo-router';

import TabBar from '@/components/TabBar';
import { useSession } from '@/store/useSession';

export default function TabsLayout() {
  const status = useSession((s) => s.status);

  // Onboarding lives outside the tabs, so the gate sits here.
  if (status === 'signed-out') return <Redirect href="/onboarding" />;

  return (
    <Tabs screenOptions={{ headerShown: false }} tabBar={(props) => <TabBar {...props} />}>
      <Tabs.Screen name="index" options={{ title: 'Home' }} />
      <Tabs.Screen name="trip" options={{ title: 'Trip' }} />
      <Tabs.Screen name="bookings" options={{ title: 'Bookings' }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
    </Tabs>
  );
}
