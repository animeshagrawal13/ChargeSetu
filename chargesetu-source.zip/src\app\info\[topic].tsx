import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';

const CONTENT: Record<string, { title: string; sections: { heading: string; body: string }[] }> = {
  privacy: {
    title: 'Privacy Policy',
    sections: [
      {
        heading: 'What this prototype stores',
        body: 'Everything you enter stays on this device, in local storage. There is no server, no account system and no analytics. Uninstalling the app erases all of it.',
      },
      {
        heading: 'Location',
        body: 'Your location is used only to sort nearby chargers by distance while the app is open. It is never transmitted anywhere. You can decline the permission and still use the app.',
      },
      {
        heading: 'Sharing',
        body: 'No data is shared with hosts, riders or third parties. Host names and addresses shown in the app are seeded demo data, not real people.',
      },
    ],
  },
  terms: {
    title: 'Terms & Conditions',
    sections: [
      {
        heading: 'Demonstration software',
        body: 'ChargeSetu is a hackathon prototype built for Smart India Hackathon 2026. It is not a live marketplace. No real bookings are made and no money changes hands.',
      },
      {
        heading: 'Payments',
        body: 'The UPI payment screen is simulated. No payment provider is integrated and no funds are transferred at any point.',
      },
      {
        heading: 'Electrical safety',
        body: 'Charging from a household socket carries real risk. Always use the charger supplied with your vehicle, never exceed a socket’s current rating, and have unfamiliar wiring checked by a qualified electrician.',
      },
    ],
  },
  faqs: {
    title: 'FAQs',
    sections: [
      {
        heading: 'Do I need to carry my own charger?',
        body: 'Usually yes. Most Indian electric two-wheelers ship with a portable charger, which is why a 5A or 15A household socket works with almost any brand. Only OEM fast chargers are brand-specific.',
      },
      {
        heading: 'What does "Slow but works" mean?',
        body: 'A 5A socket delivers roughly 0.7 kW. If your vehicle’s charger can draw more than that, it will still charge — just slower than it could. The badge warns you before you book.',
      },
      {
        heading: 'Why amperes and not volts?',
        body: 'Indian household supply is 230 V everywhere. What differs between sockets is the current rating — 5A or 15A — and that is what caps charging speed.',
      },
      {
        heading: 'How is the cost calculated?',
        body: 'Units delivered multiplied by the host’s price per kWh. Domestic tariff is roughly ₹6–8/kWh, so most hosts price between ₹8 and ₹12.',
      },
      {
        heading: 'What is the OTP for?',
        body: 'The host generates a 4-digit code when they accept your request. Entering it on arrival starts the session, so neither side can start charging without the other present.',
      },
    ],
  },
  contact: {
    title: 'Contact Us',
    sections: [
      {
        heading: 'Team ChargeSetu',
        body: 'This prototype was built for Smart India Hackathon 2026. For questions about the build, reach the team through your SIH college SPOC.',
      },
      {
        heading: 'Reporting a listing',
        body: 'Every charger detail page has a "Report this listing" link. In the prototype this records the report locally rather than notifying a moderator.',
      },
    ],
  },
};

export default function InfoScreen() {
  const { topic } = useLocalSearchParams<{ topic: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const content = CONTENT[String(topic)] ?? {
    title: 'Not found',
    sections: [{ heading: 'Nothing here', body: 'This page does not exist.' }],
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} accessibilityRole="button" accessibilityLabel="Go back" style={styles.iconBtn}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
        </Pressable>
        <Text style={[type.title, { flex: 1 }]}>{content.title}</Text>
      </View>

      <ScrollView contentContainerStyle={styles.body}>
        {content.sections.map((s) => (
          <View key={s.heading} style={styles.section}>
            <Text style={styles.heading}>{s.heading}</Text>
            <Text style={styles.text}>{s.body}</Text>
          </View>
        ))}

        {topic === 'contact' && (
          <Pressable
            onPress={() => Linking.openURL('mailto:codecrafters574@gmail.com').catch(() => {})}
            accessibilityRole="button"
            accessibilityLabel="Send an email"
            style={styles.mailBtn}>
            <MaterialCommunityIcons name="email-outline" size={20} color={colors.white} />
            <Text style={styles.mailText}>Email the team</Text>
          </Pressable>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  section: { marginBottom: spacing.xl },
  heading: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text, marginBottom: spacing.sm },
  text: { fontFamily: fonts.regular, fontSize: 15, lineHeight: 23, color: colors.textMuted },
  mailBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    minHeight: HIT_TARGET + 6,
    borderRadius: radius.md,
    backgroundColor: colors.primary,
  },
  mailText: { fontFamily: fonts.semibold, fontSize: 16, color: colors.white },
});
