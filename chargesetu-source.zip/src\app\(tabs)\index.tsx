import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import BottomSheet, { BottomSheetScrollView } from '@gorhom/bottom-sheet';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import MapView from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import ChargeMap from '@/components/ChargeMap';
import ChargerCard from '@/components/ChargerCard';
import EmptyState from '@/components/EmptyState';
import FiltersSheet from '@/components/FiltersSheet';
import SelectedChargerCard from '@/components/SelectedChargerCard';
import { DEFAULT_REGION } from '@/config';
import { repo } from '@/services';
import { applyFilters, useFilters } from '@/store/useFilters';
import { useSession } from '@/store/useSession';
import { colors, fonts, HIT_TARGET, radius, shadow, spacing, type } from '@/theme';
import { Charger } from '@/types';

const ORIGIN = { lat: DEFAULT_REGION.latitude, lng: DEFAULT_REGION.longitude };
const SNAP_POINTS = ['20%', '48%', '90%'];

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const mapRef = useRef<MapView>(null);
  const sheetRef = useRef<BottomSheet>(null);

  const vehicle = useSession((s) => s.user?.vehicle ?? null);
  const filters = useFilters();

  const [all, setAll] = useState<Charger[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      setAll(await repo.listChargers());
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load chargers.');
      setAll([]);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const matches = useMemo(
    () => (all ? applyFilters(all, ORIGIN, vehicle, filters, query) : []),
    [all, vehicle, filters, query]
  );

  const selected = useMemo(
    () => matches.find((m) => m.charger.id === selectedId) ?? null,
    [matches, selectedId]
  );

  const focusCharger = (charger: Charger) => {
    setSelectedId(charger.id);
    sheetRef.current?.snapToIndex(0);
    mapRef.current?.animateToRegion(
      {
        latitude: charger.geo.lat,
        longitude: charger.geo.lng,
        latitudeDelta: 0.02,
        longitudeDelta: 0.02,
      },
      450
    );
  };

  if (all === null) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator color={colors.primary} />
        <Text style={[type.caption, { marginTop: spacing.md }]}>Finding chargers near you…</Text>
      </View>
    );
  }

  if (error) {
    return (
      <EmptyState
        icon="alert-circle-outline"
        title="Could not load chargers"
        message={error}
        actionLabel="Try again"
        onAction={load}
      />
    );
  }

  return (
    <View style={styles.root}>
      <ChargeMap
        ref={mapRef}
        initialRegion={DEFAULT_REGION}
        chargers={matches.map((m) => m.charger)}
        selectedId={selectedId}
        onSelect={focusCharger}
      />

      <View style={[styles.searchBar, { top: insets.top + spacing.sm }]}>
        <MaterialCommunityIcons name="magnify" size={22} color={colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          value={query}
          onChangeText={setQuery}
          placeholder="Search for a locality"
          placeholderTextColor={colors.textMuted}
          returnKeyType="search"
        />
        {query.length > 0 && (
          <Pressable onPress={() => setQuery('')} accessibilityRole="button" accessibilityLabel="Clear search" hitSlop={8}>
            <MaterialCommunityIcons name="close-circle" size={20} color={colors.textMuted} />
          </Pressable>
        )}
        <View style={styles.divider} />
        <Pressable
          onPress={() => setFiltersOpen(true)}
          accessibilityRole="button"
          accessibilityLabel="Open filters"
          style={styles.filterBtn}>
          <MaterialCommunityIcons name="tune-variant" size={22} color={colors.text} />
          {matches.length !== all.length && <View style={styles.filterDot} />}
        </Pressable>
      </View>

      <View style={styles.fabs}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Show chargers near me"
          onPress={() => {
            setSelectedId(null);
            load();
            mapRef.current?.animateToRegion(DEFAULT_REGION, 450);
          }}
          style={[styles.fab, { backgroundColor: colors.primary }]}>
          <MaterialCommunityIcons name="flash" size={24} color={colors.white} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Centre on my location"
          onPress={() => mapRef.current?.animateToRegion(DEFAULT_REGION, 450)}
          style={[styles.fab, { backgroundColor: colors.info }]}>
          <MaterialCommunityIcons name="crosshairs-gps" size={24} color={colors.white} />
        </Pressable>
      </View>

      <BottomSheet
        ref={sheetRef}
        index={0}
        snapPoints={SNAP_POINTS}
        handleIndicatorStyle={styles.grabber}
        backgroundStyle={styles.sheetBg}>
        <BottomSheetScrollView contentContainerStyle={styles.sheetBody}>
          {selected ? (
            <View style={styles.selectedWrap}>
              <SelectedChargerCard
                charger={selected.charger}
                km={selected.km}
                vehicle={vehicle}
                onClose={() => setSelectedId(null)}
                onOpen={() => router.push(`/charger/${selected.charger.id}`)}
              />
            </View>
          ) : matches.length === 0 ? (
            <EmptyState
              icon="map-search-outline"
              title="No chargers match your filters"
              message="Try widening the distance or turning off compatible-only."
              actionLabel="Reset filters"
              onAction={() => {
                filters.reset();
                setQuery('');
              }}
            />
          ) : (
            <>
              <View style={styles.sheetHead}>
                <Text style={type.title}>
                  {matches.length} charger{matches.length === 1 ? '' : 's'} nearby
                </Text>
                <Text style={type.caption}>sorted by distance</Text>
              </View>
              {matches.map(({ charger, km }) => (
                <ChargerCard
                  key={charger.id}
                  charger={charger}
                  km={km}
                  vehicle={vehicle}
                  flat
                  onPress={() => router.push(`/charger/${charger.id}`)}
                />
              ))}
            </>
          )}
        </BottomSheetScrollView>
      </BottomSheet>

      <FiltersSheet visible={filtersOpen} matchCount={matches.length} onClose={() => setFiltersOpen(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  searchBar: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    minHeight: HIT_TARGET + 6,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingLeft: spacing.lg,
    paddingRight: spacing.xs,
    backgroundColor: colors.bg,
    borderRadius: radius.pill,
    ...shadow(4),
  },
  searchInput: { flex: 1, fontFamily: fonts.regular, fontSize: 15, color: colors.text },
  divider: { width: 1, height: 24, backgroundColor: colors.border },
  filterBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  filterDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.primary,
  },
  fabs: { position: 'absolute', right: spacing.lg, bottom: '24%', gap: spacing.md },
  fab: {
    width: 54,
    height: 54,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadow(5),
  },
  grabber: { backgroundColor: colors.border, width: 44 },
  sheetBg: {
    backgroundColor: colors.bg,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    ...shadow(6),
  },
  sheetBody: { paddingBottom: spacing.xxxl },
  sheetHead: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
  },
  selectedWrap: { paddingHorizontal: spacing.lg, paddingTop: spacing.xs },
});
