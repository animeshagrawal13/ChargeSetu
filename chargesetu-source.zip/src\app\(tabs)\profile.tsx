import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useRouter } from 'expo-router';
import { Alert, Pressable, ScrollView, Share, StyleSheet, Text, View } from 'react-native';

import ScreenHeader from '@/components/ScreenHeader';
import { APP_VERSION } from '@/config';
import { formatKw } from '@/lib/format';
import { repo } from '@/services';
import { useSession } from '@/store/useSession';
import { colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';

type Row = {
  icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'];
  label: string;
  onPress: () => void;
  danger?: boolean;
};

export default function ProfileScreen() {
  const router = useRouter();
  const user = useSession((s) => s.user);
  const signOut = useSession((s) => s.signOut);

  const confirmLogout = () =>
    Alert.alert('Logout', 'Are you sure you want to logout from your account?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          try {
            await signOut();
          } finally {
            router.replace('/onboarding');
          }
        },
      },
    ]);

  const confirmDelete = () =>
    Alert.alert(
      'Delete Account',
      'This removes your profile and bookings from this device. It cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              if (user) await repo.deleteUser(user.id);
              await signOut();
            } finally {
              router.replace('/onboarding');
            }
          },
        },
      ]
    );

  const resetDemo = () =>
    Alert.alert('Reset demo data?', 'Restores the seeded chargers and bookings.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reset',
        onPress: async () => {
          await repo.resetDemoData();
          Alert.alert('Done', 'Seeded chargers and bookings are back.');
        },
      },
    ]);

  const rows: Row[] = [
    { icon: 'account-edit-outline', label: 'Edit profile', onPress: () => router.push('/profile-edit') },
    { icon: 'flash-outline', label: 'Add your charging spot', onPress: () => router.push('/host/add') },
    { icon: 'map-marker-path', label: 'Plan a trip', onPress: () => router.navigate('/trip') },
    { icon: 'calculator-variant-outline', label: 'Calculators', onPress: () => router.push('/calculators') },
    { icon: 'shield-check-outline', label: 'Privacy Policy', onPress: () => router.push('/info/privacy') },
    { icon: 'file-document-outline', label: 'Terms & Conditions', onPress: () => router.push('/info/terms') },
    {
      icon: 'heart-outline',
      label: 'Refer your Friend',
      onPress: () =>
        Share.share({
          message:
            'Charge your electric scooter at a neighbour’s socket with ChargeSetu — find home chargers near you across Indore.',
        }).catch(() => {}),
    },
    { icon: 'help-circle-outline', label: 'FAQs', onPress: () => router.push('/info/faqs') },
    { icon: 'email-outline', label: 'Contact Us', onPress: () => router.push('/info/contact') },
    { icon: 'refresh', label: 'Reset demo data', onPress: resetDemo },
    { icon: 'logout', label: 'Logout', onPress: confirmLogout },
    { icon: 'delete-outline', label: 'Delete Account', onPress: confirmDelete, danger: true },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScreenHeader title="My Profile" />
      <ScrollView contentContainerStyle={styles.body}>
        <Pressable
          onPress={() => router.push('/profile-edit')}
          accessibilityRole="button"
          accessibilityLabel="Edit profile"
          style={styles.identity}>
          <View style={styles.avatar}>
            <MaterialCommunityIcons name="account" size={38} color={colors.textMuted} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={type.title}>{user?.name || 'Guest rider'}</Text>
            <Text style={type.caption}>{user?.phone ?? '—'}</Text>
            <Text style={type.caption}>
              {(user?.rating ?? 0).toFixed(1)}/5 — {user?.ratingsCount ?? 0} ratings
            </Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={22} color={colors.textMuted} />
        </Pressable>

        {!!user && (
          <View style={styles.vehicleCard}>
            <MaterialCommunityIcons name="motorbike-electric" size={28} color={colors.primaryDark} />
            <View style={{ flex: 1 }}>
              <Text style={styles.vehicleName}>
                {user.vehicle.brand} {user.vehicle.model}
              </Text>
              <Text style={type.caption}>
                {user.vehicleNumber ? `${user.vehicleNumber} • ` : ''}
                {user.vehicle.batteryKwh} kWh • {formatKw(user.vehicle.onboardChargerKw)}
              </Text>
            </View>
          </View>
        )}

        {rows.map((row) => (
          <Pressable
            key={row.label}
            onPress={row.onPress}
            accessibilityRole="button"
            accessibilityLabel={row.label}
            style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}>
            <MaterialCommunityIcons
              name={row.icon}
              size={22}
              color={row.danger ? colors.danger : colors.text}
            />
            <Text style={[styles.rowLabel, row.danger && { color: colors.danger }]}>{row.label}</Text>
            {!row.danger && <MaterialCommunityIcons name="chevron-right" size={20} color={colors.textMuted} />}
          </Pressable>
        ))}

        <Text style={styles.version}>Version {APP_VERSION}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  identity: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, paddingBottom: spacing.lg },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vehicleCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  vehicleName: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, minHeight: HIT_TARGET + 8 },
  rowPressed: { backgroundColor: colors.surface, borderRadius: radius.md },
  rowLabel: { fontFamily: fonts.medium, fontSize: 16, color: colors.text, flex: 1 },
  version: {
    fontFamily: fonts.regular,
    fontSize: 12,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: spacing.xl,
    paddingVertical: spacing.md,
  },
});
