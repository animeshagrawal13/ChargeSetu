import { forwardRef, useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import MapView, { Callout, Marker, PROVIDER_GOOGLE, Region } from 'react-native-maps';

import { formatKw, formatRate } from '@/lib/format';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import { Charger } from '@/types';
import ChargerMarker from './ChargerMarker';

type Props = {
  initialRegion: Region;
  chargers: Charger[];
  selectedId?: string | null;
  onSelect?: (charger: Charger) => void;
  showsUserLocation?: boolean;
};

/**
 * Expo Go bundles its own Google Maps key, so the base map renders without one of ours.
 * A standalone build would need EXPO_PUBLIC_GMAPS_KEY (wired up in app.config.ts).
 */
const ChargeMap = forwardRef<MapView, Props>(function ChargeMap(
  { initialRegion, chargers, selectedId, onSelect, showsUserLocation = true },
  ref
) {
  /**
   * Android needs tracksViewChanges on for the first frames or a custom marker view never
   * paints. Leaving it on permanently re-rasterises every marker each frame, which is what
   * makes panning stutter — so switch it off once they have drawn.
   */
  const [tracking, setTracking] = useState(true);
  useEffect(() => {
    setTracking(true);
    const t = setTimeout(() => setTracking(false), 900);
    return () => clearTimeout(t);
  }, [chargers.length, selectedId]);

  return (
    <MapView
      ref={ref}
      provider={PROVIDER_GOOGLE}
      style={StyleSheet.absoluteFill}
      initialRegion={initialRegion}
      showsUserLocation={showsUserLocation}
      showsMyLocationButton={false}
      showsPointsOfInterest={false}
      toolbarEnabled={false}>
      {chargers.map((charger) => (
        <Marker
          key={charger.id}
          identifier={charger.id}
          coordinate={{ latitude: charger.geo.lat, longitude: charger.geo.lng }}
          onPress={() => onSelect?.(charger)}
          tracksViewChanges={tracking}
          anchor={{ x: 0.5, y: 1 }}>
          <ChargerMarker selected={charger.id === selectedId} />

          <Callout tooltip>
            <View style={styles.callout}>
              <Text style={styles.calloutTitle} numberOfLines={1}>
                {charger.title}
              </Text>
              <Text style={styles.calloutMeta} numberOfLines={1}>
                {charger.city} • {formatKw(charger.powerKw)} • {formatRate(charger.pricePerKwh)}
              </Text>
            </View>
          </Callout>
        </Marker>
      ))}
    </MapView>
  );
});

const styles = StyleSheet.create({
  callout: {
    backgroundColor: colors.bg,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    minWidth: 180,
    ...shadow(3),
  },
  calloutTitle: { fontFamily: fonts.semibold, fontSize: 14, color: colors.text },
  calloutMeta: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
});

export default ChargeMap;
