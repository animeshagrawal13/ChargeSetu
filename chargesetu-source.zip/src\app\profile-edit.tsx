import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Button from '@/components/Button';
import { useSession } from '@/store/useSession';
import { colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';

export default function ProfileEdit() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const user = useSession((s) => s.user);
  const patchUser = useSession((s) => s.patchUser);

  const [first, last] = (user?.name ?? '').split(' ');
  const [firstName, setFirstName] = useState(first ?? '');
  const [lastName, setLastName] = useState(last ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [about, setAbout] = useState(user?.about ?? '');
  const [plate, setPlate] = useState(user?.vehicleNumber ?? '');
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      await patchUser({
        name: `${firstName.trim()} ${lastName.trim()}`.trim(),
        email: email.trim(),
        about: about.trim(),
        vehicleNumber: plate.trim().toUpperCase(),
      });
      router.back();
    } catch (e) {
      Alert.alert('Could not save', e instanceof Error ? e.message : 'Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} accessibilityRole="button" accessibilityLabel="Go back" style={styles.iconBtn}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
        </Pressable>
        <Text style={[type.title, { flex: 1 }]}>Edit profile</Text>
      </View>

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
        <View style={styles.avatarWrap}>
          <View style={styles.avatar}>
            <MaterialCommunityIcons name="account" size={48} color={colors.textMuted} />
          </View>
          <View style={styles.avatarEdit}>
            <MaterialCommunityIcons name="pencil" size={14} color={colors.white} />
          </View>
        </View>

        <View style={styles.nameRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>
              First Name <Text style={styles.req}>*</Text>
            </Text>
            <TextInput style={styles.input} value={firstName} onChangeText={setFirstName} placeholderTextColor={colors.textMuted} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>Last Name</Text>
            <TextInput style={styles.input} value={lastName} onChangeText={setLastName} placeholderTextColor={colors.textMuted} />
          </View>
        </View>

        <Text style={styles.label}>Email ID</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="you@example.com"
          placeholderTextColor={colors.textMuted}
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <Text style={styles.label}>Vehicle number</Text>
        <TextInput
          style={styles.input}
          value={plate}
          onChangeText={(t) => setPlate(t.toUpperCase().slice(0, 12))}
          placeholder="MP09 AB 1234"
          placeholderTextColor={colors.textMuted}
          autoCapitalize="characters"
        />

        <Text style={styles.label}>About Me</Text>
        <TextInput
          style={[styles.input, styles.textarea]}
          value={about}
          onChangeText={(t) => setAbout(t.slice(0, 250))}
          placeholder="Share something about you that will be visible to other EV owners"
          placeholderTextColor={colors.textMuted}
          multiline
        />
        <Text style={styles.counter}>{about.length}/250</Text>

        <Button
          label="Save changes"
          onPress={save}
          loading={busy}
          disabled={firstName.trim().length < 2}
          style={{ marginTop: spacing.xl }}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  avatarWrap: { alignSelf: 'flex-start', marginBottom: spacing.md },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarEdit: {
    position: 'absolute',
    right: 0,
    top: 4,
    width: 28,
    height: 28,
    borderRadius: radius.pill,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.bg,
  },
  nameRow: { flexDirection: 'row', gap: spacing.md },
  label: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text, marginTop: spacing.lg, marginBottom: spacing.sm },
  req: { color: colors.danger },
  input: {
    minHeight: HIT_TARGET + 8,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.regular,
    fontSize: 16,
    color: colors.text,
  },
  textarea: { minHeight: 110, paddingTop: spacing.md, textAlignVertical: 'top' },
  counter: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMuted, textAlign: 'right', marginTop: 4 },
});
