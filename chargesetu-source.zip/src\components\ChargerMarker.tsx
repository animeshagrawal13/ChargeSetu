import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { StyleSheet, View } from 'react-native';

import { colors } from '@/theme';

/** Navy teardrop with a white bolt. Scales up when it is the selected marker. */
export default function ChargerMarker({ selected = false }: { selected?: boolean }) {
  const size = selected ? 44 : 36;

  return (
    <View style={styles.wrap}>
      <View
        style={[
          styles.head,
          { width: size, height: size, borderRadius: size / 2 },
          selected && styles.headSelected,
        ]}>
        <MaterialCommunityIcons name="flash" size={size * 0.55} color={colors.white} />
      </View>
      <View
        style={[
          styles.tail,
          {
            borderLeftWidth: size * 0.18,
            borderRightWidth: size * 0.18,
            borderTopWidth: size * 0.34,
          },
          selected && styles.tailSelected,
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center' },
  head: {
    backgroundColor: colors.pin,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headSelected: {
    borderWidth: 3,
    borderColor: colors.white,
  },
  tail: {
    marginTop: -2,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: colors.pin,
  },
  tailSelected: {
    borderTopColor: colors.pin,
  },
});
