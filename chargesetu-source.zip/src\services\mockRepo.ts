import AsyncStorage from '@react-native-async-storage/async-storage';

import { SEED_CHARGERS } from '@/data/seedChargers';
import { Booking, BookingStatus, Charger, Rating, TimeSlotId, User } from '@/types';
import { NewBooking, NewCharger, NewRating, OtpResult, Repo } from './repo';

const STORAGE_KEY = 'chargesetu:v1';

/** The seeded bookings belong to this id, and onboarding reuses it, so the demo account
 *  already has history the moment it is created. */
export const DEMO_USER_ID = 'user_demo';

/** Any 4-digit code works in mock mode, but this is the one shown in the hint. */
export const MOCK_OTP = '1234';

type DB = {
  currentUserId: string | null;
  users: Record<string, User>;
  chargers: Charger[];
  bookings: Booking[];
  ratings: Rating[];
};

const hoursFromNow = (h: number) => Date.now() + h * 3_600_000;

function seedBookings(): Booking[] {
  const now = Date.now();
  return [
    // Completed, already rated — populates History and the ratings list.
    {
      id: 'bkg_completed',
      chargerId: 'chg_vijay_nagar',
      riderId: DEMO_USER_ID,
      hostId: 'host_mayank',
      slotStart: hoursFromNow(-52),
      slotEnd: hoursFromNow(-50),
      status: 'completed',
      otp: '4821',
      estimatedKwh: 2.96,
      actualKwh: 2.84,
      amount: 26.98,
      createdAt: now - 55 * 3_600_000,
      updatedAt: now - 50 * 3_600_000,
    },
    // Accepted with an OTP — the "Start charging" card in Upcoming.
    {
      id: 'bkg_accepted',
      chargerId: 'chg_bengali_square',
      riderId: DEMO_USER_ID,
      hostId: 'host_nikhil',
      slotStart: hoursFromNow(3),
      slotEnd: hoursFromNow(5),
      status: 'accepted',
      otp: '7326',
      estimatedKwh: 2.96,
      actualKwh: null,
      amount: null,
      createdAt: now - 2 * 3_600_000,
      updatedAt: now - 1 * 3_600_000,
    },
    // Still awaiting the host.
    {
      id: 'bkg_requested',
      chargerId: 'chg_rajwada',
      riderId: DEMO_USER_ID,
      hostId: 'host_aditya',
      slotStart: hoursFromNow(27),
      slotEnd: hoursFromNow(29),
      status: 'requested',
      otp: '',
      estimatedKwh: 2.96,
      actualKwh: null,
      amount: null,
      createdAt: now - 20 * 60_000,
      updatedAt: now - 20 * 60_000,
    },
  ];
}

function seedRatings(): Rating[] {
  return [
    {
      id: 'rat_seed_1',
      bookingId: 'bkg_completed',
      fromUserId: DEMO_USER_ID,
      toUserId: 'host_mayank',
      stars: 5,
      comment: 'Socket was easy to find and the parking was covered. Smooth charge.',
      createdAt: Date.now() - 50 * 3_600_000,
    },
  ];
}

/** A listing owned by the demo account, so the host dashboard has content immediately. */
function demoOwnedCharger(): Charger {
  return {
    id: 'chg_my_spot',
    hostId: DEMO_USER_ID,
    hostName: 'You',
    title: 'My Charging Spot',
    city: 'Indore',
    addressLine: 'Scheme 54, Vijay Nagar',
    landmark: 'Near Satya Sai Square',
    geo: { lat: 22.7495, lng: 75.8905 },
    socketType: 'SOCKET_15A',
    connectors: [],
    powerKw: 2.0,
    pricePerKwh: 9.0,
    amenities: ['ELECTRICITY_SOCKET', 'COVERED_PARKING', 'DRINKING_WATER', 'WIFI'],
    availability: ([0, 1, 2, 3, 4, 5, 6] as const).map((day) => ({
      day,
      slots: ['MORNING', 'EVENING'] as TimeSlotId[],
    })),
    photos: [],
    rating: 4.6,
    ratingsCount: 8,
    hostBadge: 'Trusted',
    isActive: true,
    createdAt: Date.now() - 40 * 86_400_000,
  };
}

/** Two riders waiting on the demo host, so Accept/Reject has something to act on. */
function incomingBookings(): Booking[] {
  const now = Date.now();
  return [
    {
      id: 'bkg_incoming_1',
      chargerId: 'chg_my_spot',
      riderId: 'rider_prakash',
      hostId: DEMO_USER_ID,
      slotStart: hoursFromNow(5),
      slotEnd: hoursFromNow(7),
      status: 'requested',
      otp: '',
      estimatedKwh: 2.96,
      actualKwh: null,
      amount: null,
      createdAt: now - 15 * 60_000,
      updatedAt: now - 15 * 60_000,
    },
    {
      id: 'bkg_incoming_2',
      chargerId: 'chg_my_spot',
      riderId: 'rider_anjali',
      hostId: DEMO_USER_ID,
      slotStart: hoursFromNow(-30),
      slotEnd: hoursFromNow(-28),
      status: 'completed',
      otp: '5190',
      estimatedKwh: 2.4,
      actualKwh: 2.31,
      amount: 20.79,
      createdAt: now - 34 * 3_600_000,
      updatedAt: now - 28 * 3_600_000,
    },
  ];
}

const freshDB = (): DB => ({
  currentUserId: null,
  users: {},
  chargers: [demoOwnedCharger(), ...SEED_CHARGERS],
  bookings: [...seedBookings(), ...incomingBookings()],
  ratings: seedRatings(),
});

const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));
const uid = (prefix: string) =>
  `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
const fourDigitOtp = () => String(Math.floor(1000 + Math.random() * 9000));

/**
 * In-memory store with write-through to AsyncStorage. Reads resolve from memory after
 * the first load, so the demo never blocks on storage mid-flow.
 */
class MockRepo implements Repo {
  private db: DB | null = null;
  private loading: Promise<DB> | null = null;

  private async load(): Promise<DB> {
    if (this.db) return this.db;
    if (this.loading) return this.loading;

    this.loading = (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        this.db = raw ? (JSON.parse(raw) as DB) : freshDB();
      } catch {
        // Corrupt or unavailable storage must not break the demo.
        this.db = freshDB();
      }
      return this.db;
    })();

    return this.loading;
  }

  private async persist(): Promise<void> {
    if (!this.db) return;
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(this.db));
    } catch {
      // Non-fatal: the in-memory copy is still correct for this session.
    }
  }

  // ---- auth ----

  async sendOtp(_phone: string): Promise<void> {
    // No network in mock mode; the OTP screen still renders because it demos well.
  }

  async verifyOtp(phone: string, code: string): Promise<OtpResult> {
    if (!/^\d{4}$/.test(code)) throw new Error('Enter the 4-digit code.');
    const db = await this.load();

    const existing = Object.values(db.users).find((u) => u.phone === phone);
    const userId = existing?.id ?? DEMO_USER_ID;

    db.currentUserId = userId;
    await this.persist();
    return { userId, isNewUser: !existing };
  }

  async signOut(): Promise<void> {
    const db = await this.load();
    db.currentUserId = null;
    await this.persist();
  }

  async getCurrentUserId(): Promise<string | null> {
    return (await this.load()).currentUserId;
  }

  // ---- users ----

  async getUser(id: string): Promise<User | null> {
    return clone((await this.load()).users[id] ?? null);
  }

  async saveUser(user: User): Promise<User> {
    const db = await this.load();
    db.users[user.id] = clone(user);
    db.currentUserId = user.id;
    await this.persist();
    return clone(user);
  }

  async updateUser(id: string, patch: Partial<User>): Promise<User> {
    const db = await this.load();
    const current = db.users[id];
    if (!current) throw new Error('User not found.');
    const next = { ...current, ...patch, id };
    db.users[id] = next;
    await this.persist();
    return clone(next);
  }

  async deleteUser(id: string): Promise<void> {
    const db = await this.load();
    delete db.users[id];
    db.bookings = db.bookings.filter((b) => b.riderId !== id && b.hostId !== id);
    if (db.currentUserId === id) db.currentUserId = null;
    await this.persist();
  }

  // ---- chargers ----

  async listChargers(): Promise<Charger[]> {
    return clone((await this.load()).chargers.filter((c) => c.isActive));
  }

  async getCharger(id: string): Promise<Charger | null> {
    return clone((await this.load()).chargers.find((c) => c.id === id) ?? null);
  }

  async listChargersByHost(hostId: string): Promise<Charger[]> {
    return clone((await this.load()).chargers.filter((c) => c.hostId === hostId));
  }

  async createCharger(input: NewCharger): Promise<Charger> {
    const db = await this.load();
    const charger: Charger = {
      ...input,
      id: uid('chg'),
      rating: 0,
      ratingsCount: 0,
      isActive: true,
      createdAt: Date.now(),
    };
    db.chargers.unshift(clone(charger));
    await this.persist();
    return charger;
  }

  async updateCharger(id: string, patch: Partial<Charger>): Promise<Charger> {
    const db = await this.load();
    const idx = db.chargers.findIndex((c) => c.id === id);
    if (idx === -1) throw new Error('Charger not found.');
    db.chargers[idx] = { ...db.chargers[idx], ...patch, id };
    await this.persist();
    return clone(db.chargers[idx]);
  }

  // ---- bookings ----

  async getBooking(id: string): Promise<Booking | null> {
    return clone((await this.load()).bookings.find((b) => b.id === id) ?? null);
  }

  async listBookingsForRider(riderId: string): Promise<Booking[]> {
    const db = await this.load();
    return clone(
      db.bookings.filter((b) => b.riderId === riderId).sort((a, b) => b.slotStart - a.slotStart)
    );
  }

  async listBookingsForHost(hostId: string): Promise<Booking[]> {
    const db = await this.load();
    return clone(
      db.bookings.filter((b) => b.hostId === hostId).sort((a, b) => b.slotStart - a.slotStart)
    );
  }

  async createBooking(input: NewBooking): Promise<Booking> {
    const db = await this.load();
    const booking: Booking = {
      ...input,
      id: uid('bkg'),
      status: 'requested',
      otp: '',
      actualKwh: null,
      amount: null,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    db.bookings.unshift(clone(booking));
    await this.persist();
    return booking;
  }

  async setBookingStatus(
    id: string,
    status: BookingStatus,
    patch: Partial<Booking> = {}
  ): Promise<Booking> {
    const db = await this.load();
    const idx = db.bookings.findIndex((b) => b.id === id);
    if (idx === -1) throw new Error('Booking not found.');

    const next: Booking = { ...db.bookings[idx], ...patch, status, id, updatedAt: Date.now() };
    // The OTP comes into existence at the moment the host accepts.
    if (status === 'accepted' && !next.otp) next.otp = fourDigitOtp();

    db.bookings[idx] = next;
    await this.persist();
    return clone(next);
  }

  // ---- ratings ----

  async createRating(input: NewRating): Promise<Rating> {
    const db = await this.load();
    const rating: Rating = { ...input, id: uid('rat'), createdAt: Date.now() };
    db.ratings.unshift(clone(rating));

    // Fold the new star into the charger's running average when it targets a host.
    const charger = db.chargers.find((c) => c.hostId === input.toUserId);
    if (charger) {
      const total = charger.rating * charger.ratingsCount + input.stars;
      charger.ratingsCount += 1;
      charger.rating = Number((total / charger.ratingsCount).toFixed(2));
    }

    const user = db.users[input.toUserId];
    if (user) {
      const total = user.rating * user.ratingsCount + input.stars;
      user.ratingsCount += 1;
      user.rating = Number((total / user.ratingsCount).toFixed(2));
    }

    await this.persist();
    return rating;
  }

  async listRatingsForUser(userId: string): Promise<Rating[]> {
    return clone((await this.load()).ratings.filter((r) => r.toUserId === userId));
  }

  async resetDemoData(): Promise<void> {
    const keepUser = this.db?.currentUserId ? this.db.users[this.db.currentUserId] : null;
    this.db = freshDB();
    if (keepUser) {
      this.db.users[keepUser.id] = keepUser;
      this.db.currentUserId = keepUser.id;
    }
    await this.persist();
  }
}

export const mockRepo = new MockRepo();
