import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { format } from 'date-fns';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Button from '@/components/Button';
import EmptyState from '@/components/EmptyState';
import { formatDuration, formatKwh, formatMoney } from '@/lib/format';
import { repo } from '@/services';
import { useSession } from '@/store/useSession';
import { card, colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';
import { Booking, Charger } from '@/types';

type Phase = 'summary' | 'paying' | 'paid' | 'rating' | 'done';

export default function BookingScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const user = useSession((s) => s.user);

  const [booking, setBooking] = useState<Booking | null | 'missing'>(null);
  const [charger, setCharger] = useState<Charger | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [otpEntry, setOtpEntry] = useState('');
  const [otpError, setOtpError] = useState<string | null>(null);

  const [elapsed, setElapsed] = useState(0); // seconds
  const [kwh, setKwh] = useState(0);
  const [phase, setPhase] = useState<Phase>('summary');
  const [stars, setStars] = useState(0);
  const [comment, setComment] = useState('');

  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const refresh = useCallback(async () => {
    const b = await repo.getBooking(String(id));
    if (!b) return setBooking('missing');
    setBooking(b);
    setCharger(await repo.getCharger(b.chargerId));
  }, [id]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Mock mode stands in for the host: accept the request after a beat.
  useEffect(() => {
    if (!booking || booking === 'missing' || booking.status !== 'requested') return;
    const t = setTimeout(async () => {
      const updated = await repo.setBookingStatus(booking.id, 'accepted');
      setBooking(updated);
      setToast('Host accepted your request');
      setTimeout(() => setToast(null), 2500);
    }, 3000);
    return () => clearTimeout(t);
  }, [booking]);

  // Live session: kWh rises at powerKw per hour, sampled every second.
  useEffect(() => {
    if (!booking || booking === 'missing' || booking.status !== 'active' || !charger) return;
    timer.current = setInterval(() => {
      setElapsed((s) => s + 1);
      setKwh((k) => k + charger.powerKw / 3600);
    }, 1000);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [booking, charger]);

  if (booking === null) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (booking === 'missing' || !charger) {
    return (
      <EmptyState
        icon="alert-circle-outline"
        title="Booking not found"
        actionLabel="Go back"
        onAction={() => router.replace('/bookings')}
      />
    );
  }

  const startCharging = async () => {
    if (otpEntry !== booking.otp) {
      setOtpError('That code does not match. Check with your host.');
      return;
    }
    setOtpError(null);
    setBooking(await repo.setBookingStatus(booking.id, 'active'));
  };

  const stopCharging = async () => {
    if (timer.current) clearInterval(timer.current);
    const amount = kwh * charger.pricePerKwh;
    setBooking(await repo.setBookingStatus(booking.id, 'active', { actualKwh: kwh, amount }));
    setPhase('summary');
  };

  const pay = async () => {
    setPhase('paying');
    setTimeout(() => {
      setPhase('paid');
      setTimeout(() => setPhase('rating'), 900);
    }, 1600);
  };

  const submitRating = async () => {
    await repo.createRating({
      bookingId: booking.id,
      fromUserId: user?.id ?? booking.riderId,
      toUserId: booking.hostId,
      stars,
      comment: comment.trim(),
    });
    const done = await repo.setBookingStatus(booking.id, 'completed');
    setBooking(done);
    setPhase('done');
  };

  const header = (
    <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
      <Pressable
        onPress={() => router.replace('/bookings')}
        accessibilityRole="button"
        accessibilityLabel="Go back"
        style={styles.iconBtn}>
        <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
      </Pressable>
      <Text style={[type.title, { flex: 1 }]} numberOfLines={1}>
        {charger.title}
      </Text>
    </View>
  );

  // ---- charging finished: pay, then rate ----
  if (booking.status === 'active' && booking.actualKwh !== null) {
    return (
      <View style={styles.root}>
        {header}
        <ScrollView contentContainerStyle={styles.body}>
          {phase === 'rating' || phase === 'done' ? (
            phase === 'done' ? (
              <View style={styles.doneBox}>
                <MaterialCommunityIcons name="check-decagram" size={64} color={colors.primary} />
                <Text style={type.h2}>All done</Text>
                <Text style={[type.caption, styles.centerText]}>
                  Thanks for charging with {charger.hostName}.
                </Text>
                <Button label="Back to bookings" onPress={() => router.replace('/bookings')} style={{ marginTop: spacing.xl }} />
              </View>
            ) : (
              <>
                <Text style={type.h2}>Rate your host</Text>
                <Text style={type.caption}>How was charging at {charger.title}?</Text>
                <View style={styles.stars}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <Pressable
                      key={n}
                      onPress={() => setStars(n)}
                      accessibilityRole="button"
                      accessibilityLabel={`${n} star${n === 1 ? '' : 's'}`}>
                      <MaterialCommunityIcons
                        name={n <= stars ? 'star' : 'star-outline'}
                        size={40}
                        color={colors.warning}
                      />
                    </Pressable>
                  ))}
                </View>
                <TextInput
                  style={styles.commentInput}
                  value={comment}
                  onChangeText={setComment}
                  placeholder="Add a comment (optional)"
                  placeholderTextColor={colors.textMuted}
                  multiline
                />
                <Button label="Submit rating" disabled={stars === 0} onPress={submitRating} style={{ marginTop: spacing.xl }} />
              </>
            )
          ) : (
            <>
              <Text style={type.h2}>Charging complete</Text>
              <View style={styles.summary}>
                <Row label="Units delivered" value={formatKwh(booking.actualKwh)} />
                <Row label="Duration" value={formatDuration(elapsed / 60)} />
                <Row label="Rate" value={`${formatMoney(charger.pricePerKwh)}/kWh`} />
                <View style={styles.divider} />
                <Row label="Total" value={formatMoney(booking.amount ?? 0)} strong />
              </View>

              {phase === 'paying' ? (
                <View style={styles.payBox}>
                  <ActivityIndicator color={colors.primary} />
                  <Text style={type.caption}>Contacting your UPI app…</Text>
                </View>
              ) : phase === 'paid' ? (
                <View style={styles.payBox}>
                  <MaterialCommunityIcons name="check-circle" size={48} color={colors.primary} />
                  <Text style={type.title}>Payment successful</Text>
                </View>
              ) : (
                <Button
                  label={`Pay ${formatMoney(booking.amount ?? 0)} via UPI`}
                  onPress={pay}
                  style={{ marginTop: spacing.xl }}
                />
              )}
              <Text style={[type.caption, styles.centerText, { marginTop: spacing.md }]}>
                Prototype — no real payment is processed.
              </Text>
            </>
          )}
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      {header}
      <ScrollView contentContainerStyle={styles.body}>
        {!!toast && (
          <View style={styles.toast}>
            <MaterialCommunityIcons name="check-circle" size={18} color={colors.white} />
            <Text style={styles.toastText}>{toast}</Text>
          </View>
        )}

        <View style={styles.slotCard}>
          <Text style={type.caption}>Your slot</Text>
          <Text style={type.title}>
            {format(new Date(booking.slotStart), 'EEE d MMM, h:mm a')} –{' '}
            {format(new Date(booking.slotEnd), 'h:mm a')}
          </Text>
          <Text style={type.caption}>
            {charger.addressLine} • {charger.hostName}
          </Text>
        </View>

        {booking.status === 'requested' && (
          <View style={styles.waitBox}>
            <ActivityIndicator color={colors.warning} />
            <Text style={type.title}>Waiting for the host</Text>
            <Text style={[type.caption, styles.centerText]}>
              {charger.hostName} usually replies within a few minutes.
            </Text>
          </View>
        )}

        {booking.status === 'accepted' && (
          <>
            <View style={styles.otpCard}>
              <Text style={type.caption}>Show this code to your host</Text>
              <Text style={styles.otpBig}>{booking.otp}</Text>
            </View>

            <Text style={styles.section}>Arrived? Enter the code to begin</Text>
            <TextInput
              style={styles.otpInput}
              value={otpEntry}
              onChangeText={(t) => setOtpEntry(t.replace(/\D/g, '').slice(0, 4))}
              placeholder="••••"
              placeholderTextColor={colors.textMuted}
              keyboardType="number-pad"
            />
            {!!otpError && <Text style={styles.error}>{otpError}</Text>}
            <Button
              label="Start charging"
              disabled={otpEntry.length !== 4}
              onPress={startCharging}
              style={{ marginTop: spacing.lg }}
            />
          </>
        )}

        {booking.status === 'active' && (
          <>
            <View style={styles.liveCard}>
              <MaterialCommunityIcons name="flash" size={40} color={colors.primary} />
              <Text style={styles.liveKwh}>{formatKwh(kwh)}</Text>
              <Text style={type.caption}>delivered</Text>
              <Text style={styles.liveTimer}>{formatDuration(elapsed / 60)}</Text>
              <Text style={styles.liveCost}>{formatMoney(kwh * charger.pricePerKwh)}</Text>
            </View>
            <Button label="Stop charging" variant="danger" onPress={stopCharging} style={{ marginTop: spacing.xl }} />
          </>
        )}

        {(booking.status === 'completed' || booking.status === 'cancelled') && (
          <View style={styles.doneBox}>
            <MaterialCommunityIcons name="check-decagram" size={56} color={colors.primary} />
            <Text style={type.title}>This booking is {booking.status}</Text>
            {booking.amount !== null && <Text style={type.body}>{formatMoney(booking.amount)}</Text>}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <View style={styles.row}>
      <Text style={type.body}>{label}</Text>
      <Text style={strong ? styles.rowStrong : styles.rowVal}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primary,
    padding: spacing.md,
    borderRadius: radius.md,
    marginBottom: spacing.lg,
  },
  toastText: { fontFamily: fonts.medium, fontSize: 14, color: colors.white },
  slotCard: { ...card, gap: 2 },
  waitBox: { ...card, alignItems: 'center', gap: spacing.sm, marginTop: spacing.lg },
  otpCard: {
    ...card,
    alignItems: 'center',
    marginTop: spacing.lg,
    backgroundColor: colors.primarySoft,
    borderColor: colors.primary,
  },
  otpBig: { fontFamily: fonts.bold, fontSize: 44, letterSpacing: 10, color: colors.primaryDark },
  section: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text, marginTop: spacing.xl },
  otpInput: {
    minHeight: HIT_TARGET + 8,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    marginTop: spacing.sm,
    fontFamily: fonts.bold,
    fontSize: 24,
    letterSpacing: 12,
    textAlign: 'center',
    color: colors.text,
  },
  error: { fontFamily: fonts.medium, fontSize: 13, color: colors.danger, marginTop: spacing.sm },
  liveCard: { ...card, alignItems: 'center', gap: 2, marginTop: spacing.lg },
  liveKwh: { fontFamily: fonts.bold, fontSize: 40, color: colors.text },
  liveTimer: { fontFamily: fonts.semibold, fontSize: 20, color: colors.textMuted, marginTop: spacing.md },
  liveCost: { fontFamily: fonts.semibold, fontSize: 18, color: colors.primaryDark },
  summary: { ...card, gap: spacing.md, marginTop: spacing.lg },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  rowVal: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
  rowStrong: { fontFamily: fonts.bold, fontSize: 20, color: colors.text },
  divider: { height: 1, backgroundColor: colors.border },
  payBox: { ...card, alignItems: 'center', gap: spacing.md, marginTop: spacing.xl },
  stars: { flexDirection: 'row', gap: spacing.sm, marginVertical: spacing.xl, justifyContent: 'center' },
  commentInput: {
    minHeight: 96,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.lg,
    fontFamily: fonts.regular,
    fontSize: 15,
    color: colors.text,
    textAlignVertical: 'top',
  },
  doneBox: { alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.xxxl },
  centerText: { textAlign: 'center' },
});
