import { Booking, BookingStatus, Charger, Rating, User } from '@/types';
import { NewBooking, NewCharger, NewRating, OtpResult, Repo } from './repo';

/**
 * Firebase implementation — Auth phone OTP + Firestore.
 *
 * STUB. Every method is declared so the interface boundary is real and the compiler
 * enforces parity with MockRepo, but the bodies are not wired yet. Flipping
 * `USE_MOCK = false` in src/config.ts before finishing this will throw immediately
 * rather than fail silently mid-demo.
 *
 * To finish it:
 *   1. npm install firebase
 *   2. Fill EXPO_PUBLIC_FIREBASE_* in .env (see .env.example)
 *   3. Initialise the app here and replace each `notWired` call
 *   4. Firestore collections: users, chargers, bookings, ratings
 */
const notWired = (method: string): never => {
  throw new Error(
    `FirebaseRepo.${method} is not wired yet. Set USE_MOCK = true in src/config.ts, ` +
      `or finish the Firebase implementation first.`
  );
};

class FirebaseRepo implements Repo {
  // ---- auth ----
  async sendOtp(_phone: string): Promise<void> {
    return notWired('sendOtp');
  }
  async verifyOtp(_phone: string, _code: string): Promise<OtpResult> {
    return notWired('verifyOtp');
  }
  async signOut(): Promise<void> {
    return notWired('signOut');
  }
  async getCurrentUserId(): Promise<string | null> {
    return notWired('getCurrentUserId');
  }

  // ---- users ----
  async getUser(_id: string): Promise<User | null> {
    return notWired('getUser');
  }
  async saveUser(_user: User): Promise<User> {
    return notWired('saveUser');
  }
  async updateUser(_id: string, _patch: Partial<User>): Promise<User> {
    return notWired('updateUser');
  }
  async deleteUser(_id: string): Promise<void> {
    return notWired('deleteUser');
  }

  // ---- chargers ----
  async listChargers(): Promise<Charger[]> {
    return notWired('listChargers');
  }
  async getCharger(_id: string): Promise<Charger | null> {
    return notWired('getCharger');
  }
  async listChargersByHost(_hostId: string): Promise<Charger[]> {
    return notWired('listChargersByHost');
  }
  async createCharger(_input: NewCharger): Promise<Charger> {
    return notWired('createCharger');
  }
  async updateCharger(_id: string, _patch: Partial<Charger>): Promise<Charger> {
    return notWired('updateCharger');
  }

  // ---- bookings ----
  async getBooking(_id: string): Promise<Booking | null> {
    return notWired('getBooking');
  }
  async listBookingsForRider(_riderId: string): Promise<Booking[]> {
    return notWired('listBookingsForRider');
  }
  async listBookingsForHost(_hostId: string): Promise<Booking[]> {
    return notWired('listBookingsForHost');
  }
  async createBooking(_input: NewBooking): Promise<Booking> {
    return notWired('createBooking');
  }
  async setBookingStatus(
    _id: string,
    _status: BookingStatus,
    _patch?: Partial<Booking>
  ): Promise<Booking> {
    return notWired('setBookingStatus');
  }

  // ---- ratings ----
  async createRating(_input: NewRating): Promise<Rating> {
    return notWired('createRating');
  }
  async listRatingsForUser(_userId: string): Promise<Rating[]> {
    return notWired('listRatingsForUser');
  }

  async resetDemoData(): Promise<void> {
    return notWired('resetDemoData');
  }
}

export const firebaseRepo = new FirebaseRepo();
