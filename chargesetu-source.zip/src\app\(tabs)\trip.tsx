import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useRouter } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Button from '@/components/Button';
import ChargerCard from '@/components/ChargerCard';
import EmptyState from '@/components/EmptyState';
import ScreenHeader from '@/components/ScreenHeader';
import { LOCALITIES } from '@/data/localities';
import { formatKm } from '@/lib/format';
import { distanceToSegmentKm, haversineKm } from '@/lib/geo';
import { repo } from '@/services';
import { useSession } from '@/store/useSession';
import { card, colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';
import { Charger } from '@/types';

/** Chargers within this distance of the straight line count as "on the way". */
const CORRIDOR_KM = 5;

type Place = (typeof LOCALITIES)[number];

export default function TripScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const vehicle = useSession((s) => s.user?.vehicle ?? null);

  const [chargers, setChargers] = useState<Charger[]>([]);
  const [source, setSource] = useState<Place | null>(null);
  const [dest, setDest] = useState<Place | null>(null);
  const [picking, setPicking] = useState<'source' | 'dest' | null>(null);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    repo.listChargers().then(setChargers).catch(() => setChargers([]));
  }, []);

  const results = useMemo(() => {
    if (!source || !dest) return [];
    return chargers
      .map((charger) => {
        const detour = distanceToSegmentKm(charger.geo, source, dest);
        return {
          charger,
          detour,
          alongRoute: haversineKm({ lat: source.lat, lng: source.lng }, charger.geo),
        };
      })
      .filter((r) => r.detour <= CORRIDOR_KM)
      .sort((a, b) => a.alongRoute - b.alongRoute);
  }, [chargers, source, dest]);

  const routeKm = source && dest ? haversineKm(source, dest) : 0;

  const region = useMemo(() => {
    if (!source || !dest) return null;
    return {
      latitude: (source.lat + dest.lat) / 2,
      longitude: (source.lng + dest.lng) / 2,
      latitudeDelta: Math.max(Math.abs(source.lat - dest.lat) * 2.2, 0.05),
      longitudeDelta: Math.max(Math.abs(source.lng - dest.lng) * 2.2, 0.05),
    };
  }, [source, dest]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <ScreenHeader title="Plan Your Trip" />

      <ScrollView contentContainerStyle={styles.body}>
        <Pressable
          onPress={() => setPicking('source')}
          accessibilityRole="button"
          accessibilityLabel="Choose source location"
          style={styles.field}>
          <MaterialCommunityIcons name="circle-outline" size={20} color={colors.primary} />
          <Text style={[styles.fieldText, !source && styles.placeholder]}>
            {source?.name ?? 'Source location'}
          </Text>
        </Pressable>

        <Pressable
          onPress={() => setPicking('dest')}
          accessibilityRole="button"
          accessibilityLabel="Choose destination location"
          style={styles.field}>
          <MaterialCommunityIcons name="map-marker" size={20} color={colors.danger} />
          <Text style={[styles.fieldText, !dest && styles.placeholder]}>
            {dest?.name ?? 'Destination location'}
          </Text>
        </Pressable>

        <Button
          label="Find Chargers"
          disabled={!source || !dest}
          onPress={() => setSearched(true)}
          style={{ marginTop: spacing.md }}
        />

        {searched && source && dest && region && (
          <>
            <View style={styles.mapBox}>
              <MapView
                provider={PROVIDER_GOOGLE}
                style={StyleSheet.absoluteFill}
                initialRegion={region}
                pointerEvents="none">
                <Polyline
                  coordinates={[
                    { latitude: source.lat, longitude: source.lng },
                    { latitude: dest.lat, longitude: dest.lng },
                  ]}
                  strokeColor={colors.primary}
                  strokeWidth={4}
                />
                <Marker coordinate={{ latitude: source.lat, longitude: source.lng }} pinColor={colors.primary} />
                <Marker coordinate={{ latitude: dest.lat, longitude: dest.lng }} pinColor={colors.danger} />
                {results.map((r) => (
                  <Marker
                    key={r.charger.id}
                    coordinate={{ latitude: r.charger.geo.lat, longitude: r.charger.geo.lng }}
                    pinColor={colors.pin}
                  />
                ))}
              </MapView>
            </View>

            <View style={styles.routeSummary}>
              <MaterialCommunityIcons name="map-marker-distance" size={20} color={colors.primaryDark} />
              <Text style={styles.routeText}>
                {formatKm(routeKm)} route • {results.length} charger
                {results.length === 1 ? '' : 's'} within {CORRIDOR_KM} km
              </Text>
            </View>

            {results.length === 0 ? (
              <EmptyState
                icon="map-search-outline"
                title="No chargers on this route"
                message={`Nothing within ${CORRIDOR_KM} km of the straight line between these two points.`}
              />
            ) : (
              results.map((r) => (
                <View key={r.charger.id} style={styles.resultWrap}>
                  <ChargerCard
                    charger={r.charger}
                    km={r.alongRoute}
                    vehicle={vehicle}
                    onPress={() => router.push(`/charger/${r.charger.id}`)}
                  />
                  <Text style={styles.detour}>
                    {formatKm(r.detour)} detour • {formatKm(r.alongRoute)} from start
                  </Text>
                </View>
              ))
            )}
          </>
        )}
      </ScrollView>

      <Modal visible={picking !== null} animationType="slide" transparent onRequestClose={() => setPicking(null)}>
        <View style={styles.backdrop}>
          <View style={[styles.picker, { paddingBottom: insets.bottom + spacing.lg }]}>
            <View style={styles.pickerHead}>
              <Text style={[type.title, { flex: 1 }]}>
                {picking === 'source' ? 'Starting from' : 'Going to'}
              </Text>
              <Pressable onPress={() => setPicking(null)} accessibilityRole="button" accessibilityLabel="Close" hitSlop={8}>
                <MaterialCommunityIcons name="close" size={24} color={colors.text} />
              </Pressable>
            </View>
            <ScrollView>
              {LOCALITIES.map((p) => (
                <Pressable
                  key={p.name}
                  onPress={() => {
                    if (picking === 'source') setSource(p);
                    else setDest(p);
                    setPicking(null);
                    setSearched(false);
                  }}
                  accessibilityRole="button"
                  accessibilityLabel={p.name}
                  style={styles.pickerRow}>
                  <MaterialCommunityIcons name="map-marker-outline" size={20} color={colors.textMuted} />
                  <Text style={styles.pickerText}>{p.name}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl, gap: spacing.md },
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    minHeight: HIT_TARGET + 8,
    paddingHorizontal: spacing.lg,
    backgroundColor: colors.bg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  fieldText: { fontFamily: fonts.medium, fontSize: 15, color: colors.text, flex: 1 },
  placeholder: { color: colors.textMuted, fontFamily: fonts.regular },
  mapBox: {
    height: 220,
    borderRadius: radius.lg,
    overflow: 'hidden',
    marginTop: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  routeSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primarySoft,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  routeText: { fontFamily: fonts.semibold, fontSize: 14, color: colors.primaryDark, flex: 1 },
  resultWrap: { gap: 4 },
  detour: { fontFamily: fonts.medium, fontSize: 12, color: colors.textMuted, paddingLeft: spacing.xs },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)', justifyContent: 'flex-end' },
  picker: {
    maxHeight: '75%',
    backgroundColor: colors.bg,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: spacing.lg,
  },
  pickerHead: { flexDirection: 'row', alignItems: 'center', paddingBottom: spacing.md },
  pickerRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, minHeight: HIT_TARGET + 6 },
  pickerText: { fontFamily: fonts.medium, fontSize: 16, color: colors.text },
});
