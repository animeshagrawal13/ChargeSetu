import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { format } from 'date-fns';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import Button from '@/components/Button';
import EmptyState from '@/components/EmptyState';
import ScreenHeader from '@/components/ScreenHeader';
import { formatMoney } from '@/lib/format';
import { repo } from '@/services';
import { useSession } from '@/store/useSession';
import { card, colors, fonts, radius, spacing, type } from '@/theme';
import { Booking, BookingStatus, Charger } from '@/types';

const STATUS_COLOR: Record<BookingStatus, string> = {
  requested: colors.warning,
  accepted: colors.primary,
  active: colors.info,
  completed: colors.textMuted,
  rejected: colors.danger,
  cancelled: colors.danger,
};

const UPCOMING: BookingStatus[] = ['requested', 'accepted', 'active'];

export default function BookingsScreen() {
  const router = useRouter();
  const user = useSession((s) => s.user);
  const [tab, setTab] = useState<'upcoming' | 'history'>('upcoming');
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [chargers, setChargers] = useState<Record<string, Charger>>({});
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    setError(null);
    try {
      const [bs, cs] = await Promise.all([repo.listBookingsForRider(user.id), repo.listChargers()]);
      setBookings(bs);
      setChargers(Object.fromEntries(cs.map((c) => [c.id, c])));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load your bookings.');
      setBookings([]);
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const cancel = async (b: Booking) => {
    await repo.setBookingStatus(b.id, 'cancelled');
    load();
  };

  const shown = (bookings ?? []).filter((b) =>
    tab === 'upcoming' ? UPCOMING.includes(b.status) : !UPCOMING.includes(b.status)
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <ScreenHeader title="Bookings" />

      <View style={styles.tabs}>
        {(['upcoming', 'history'] as const).map((t) => (
          <Pressable
            key={t}
            onPress={() => setTab(t)}
            accessibilityRole="tab"
            accessibilityState={{ selected: tab === t }}
            accessibilityLabel={t === 'upcoming' ? 'Upcoming' : 'History'}
            style={[styles.tab, tab === t && styles.tabOn]}>
            <Text style={[styles.tabText, tab === t && styles.tabTextOn]}>
              {t === 'upcoming' ? 'Upcoming' : 'History'}
            </Text>
          </Pressable>
        ))}
      </View>

      {bookings === null ? (
        <View style={styles.centered}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : error ? (
        <EmptyState icon="alert-circle-outline" title="Could not load bookings" message={error} actionLabel="Try again" onAction={load} />
      ) : shown.length === 0 ? (
        <EmptyState
          icon="calendar-blank-outline"
          title="No bookings yet"
          message="Start by booking a charger."
          actionLabel="Find a charger"
          onAction={() => router.replace('/')}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.list}>
          {shown.map((b) => {
            const c = chargers[b.chargerId];
            return (
              <Pressable
                key={b.id}
                onPress={() => router.push(`/booking/${b.id}`)}
                accessibilityRole="button"
                accessibilityLabel={c?.title ?? 'Booking'}
                style={styles.card}>
                <View style={styles.cardTop}>
                  <Text style={[type.title, { flex: 1 }]} numberOfLines={1}>
                    {c?.title ?? 'Charger'}
                  </Text>
                  <View style={[styles.pill, { backgroundColor: STATUS_COLOR[b.status] }]}>
                    <Text style={styles.pillText}>{b.status}</Text>
                  </View>
                </View>

                <Text style={type.caption}>
                  {format(new Date(b.slotStart), 'EEE d MMM, h:mm a')}
                </Text>

                {b.otp ? (
                  <View style={styles.otpRow}>
                    <MaterialCommunityIcons name="key-variant" size={16} color={colors.primaryDark} />
                    <Text style={styles.otp}>{b.otp}</Text>
                  </View>
                ) : null}

                {b.amount !== null && <Text style={styles.amount}>{formatMoney(b.amount)}</Text>}

                <View style={styles.actions}>
                  {b.status === 'requested' && (
                    <Button label="Cancel" variant="outline" onPress={() => cancel(b)} style={{ flex: 1 }} />
                  )}
                  {b.status === 'accepted' && (
                    <Button label="Start charging" onPress={() => router.push(`/booking/${b.id}`)} style={{ flex: 1 }} />
                  )}
                  {b.status === 'active' && (
                    <Button label="Resume session" onPress={() => router.push(`/booking/${b.id}`)} style={{ flex: 1 }} />
                  )}
                </View>
              </Pressable>
            );
          })}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  tabs: { flexDirection: 'row', backgroundColor: colors.bg, paddingHorizontal: spacing.lg, gap: spacing.sm, paddingBottom: spacing.sm },
  tab: { flex: 1, paddingVertical: spacing.md, borderRadius: radius.md, alignItems: 'center', backgroundColor: colors.surface },
  tabOn: { backgroundColor: colors.primarySoft },
  tabText: { fontFamily: fonts.medium, fontSize: 14, color: colors.textMuted },
  tabTextOn: { color: colors.primaryDark, fontFamily: fonts.semibold },
  list: { padding: spacing.lg, gap: spacing.md },
  card: { ...card, gap: spacing.xs },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  pill: { paddingHorizontal: spacing.md, paddingVertical: 4, borderRadius: radius.pill },
  pillText: { fontFamily: fonts.semibold, fontSize: 11, color: colors.white },
  otpRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  otp: { fontFamily: fonts.bold, fontSize: 16, letterSpacing: 4, color: colors.primaryDark },
  amount: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
  actions: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm },
});
