import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { formatMoney } from '@/lib/format';
import { useSession } from '@/store/useSession';
import { card, colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';

/** Typical Indian electric two-wheeler does roughly 30 km on a kWh. */
const KM_PER_KWH = 30;

function Field({
  label,
  value,
  onChange,
  suffix,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  suffix?: string;
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View style={styles.inputWrap}>
        <TextInput
          style={styles.input}
          value={value}
          onChangeText={(t) => onChange(t.replace(/[^\d.]/g, ''))}
          keyboardType="decimal-pad"
          accessibilityLabel={label}
        />
        {!!suffix && <Text style={styles.suffix}>{suffix}</Text>}
      </View>
    </View>
  );
}

function Result({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <View style={styles.resultRow}>
      <Text style={type.body}>{label}</Text>
      <Text style={strong ? styles.resultStrong : styles.resultValue}>{value}</Text>
    </View>
  );
}

export default function Calculators() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const vehicle = useSession((s) => s.user?.vehicle ?? null);

  const [units, setUnits] = useState(String(vehicle?.batteryKwh ?? 3));
  const [rate, setRate] = useState('9');
  const [mileage, setMileage] = useState('45');
  const [petrolPrice, setPetrolPrice] = useState('110');

  const [kmElectric, setKmElectric] = useState('500');

  const [sessions, setSessions] = useState('6');
  const [unitsPerSession, setUnitsPerSession] = useState('3');
  const [margin, setMargin] = useState('3');

  const n = (s: string) => (Number.isFinite(Number(s)) ? Number(s) : 0);

  const chargeCost = n(units) * n(rate);
  const rangeKm = n(units) * KM_PER_KWH;
  const petrolCost = n(mileage) > 0 ? (rangeKm / n(mileage)) * n(petrolPrice) : 0;
  const savings = petrolCost - chargeCost;

  const co2Saved = n(kmElectric) * 0.021;

  const monthlyEarnings = n(sessions) * n(unitsPerSession) * n(margin) * 4.33;

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} accessibilityRole="button" accessibilityLabel="Go back" style={styles.iconBtn}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
        </Pressable>
        <Text style={[type.title, { flex: 1 }]}>Calculators</Text>
      </View>

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
        <View style={styles.calc}>
          <View style={styles.calcHead}>
            <MaterialCommunityIcons name="cash-multiple" size={22} color={colors.primaryDark} />
            <Text style={type.title}>Charging cost vs petrol</Text>
          </View>

          <Field label="Units charged" value={units} onChange={setUnits} suffix="kWh" />
          <Field label="Host rate" value={rate} onChange={setRate} suffix="₹/kWh" />
          <Field label="Petrol scooter mileage" value={mileage} onChange={setMileage} suffix="km/l" />
          <Field label="Petrol price" value={petrolPrice} onChange={setPetrolPrice} suffix="₹/l" />

          <View style={styles.results}>
            <Result label={`Range added (~${KM_PER_KWH} km/kWh)`} value={`${rangeKm.toFixed(0)} km`} />
            <Result label="Cost to charge" value={formatMoney(chargeCost)} />
            <Result label="Same range on petrol" value={formatMoney(petrolCost)} />
            <View style={styles.divider} />
            <Result label="You save" value={formatMoney(Math.max(0, savings))} strong />
          </View>
        </View>

        <View style={styles.calc}>
          <View style={styles.calcHead}>
            <MaterialCommunityIcons name="leaf" size={22} color={colors.primaryDark} />
            <Text style={type.title}>CO₂ saved</Text>
          </View>

          <Field label="Distance ridden electric" value={kmElectric} onChange={setKmElectric} suffix="km" />

          <View style={styles.results}>
            <Result label="CO₂ avoided" value={`${co2Saved.toFixed(2)} kg`} strong />
          </View>
          <Text style={styles.assumption}>
            Assumes 0.021 kg CO₂ avoided per km versus an equivalent petrol two-wheeler.
          </Text>
        </View>

        <View style={styles.calc}>
          <View style={styles.calcHead}>
            <MaterialCommunityIcons name="home-lightning-bolt-outline" size={22} color={colors.primaryDark} />
            <Text style={type.title}>Host earnings</Text>
          </View>

          <Field label="Sessions per week" value={sessions} onChange={setSessions} />
          <Field label="Units per session" value={unitsPerSession} onChange={setUnitsPerSession} suffix="kWh" />
          <Field label="Margin over tariff" value={margin} onChange={setMargin} suffix="₹/kWh" />

          <View style={styles.results}>
            <Result label="Estimated monthly earnings" value={formatMoney(monthlyEarnings)} strong />
          </View>
          <Text style={styles.assumption}>
            Margin is what you keep after your own electricity tariff, which is roughly ₹6–8/kWh.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.sm,
    backgroundColor: colors.bg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl, gap: spacing.lg },
  calc: { ...card },
  calcHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  field: { marginTop: spacing.md },
  fieldLabel: { fontFamily: fonts.medium, fontSize: 13, color: colors.textMuted, marginBottom: 4 },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
  },
  input: { flex: 1, minHeight: HIT_TARGET, fontFamily: fonts.medium, fontSize: 16, color: colors.text },
  suffix: { fontFamily: fonts.regular, fontSize: 13, color: colors.textMuted },
  results: { marginTop: spacing.lg, gap: spacing.sm },
  resultRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  resultValue: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
  resultStrong: { fontFamily: fonts.bold, fontSize: 20, color: colors.primaryDark },
  divider: { height: 1, backgroundColor: colors.border },
  assumption: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMuted, marginTop: spacing.md },
});
