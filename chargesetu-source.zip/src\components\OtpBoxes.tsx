import { useRef } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

import { colors, fonts, radius, spacing } from '@/theme';

type Props = {
  length?: number;
  value: string;
  onChange: (v: string) => void;
};

/**
 * Separate OTP boxes backed by one hidden input — far more reliable on Android than
 * chaining focus between several inputs.
 */
export default function OtpBoxes({ length = 6, value, onChange }: Props) {
  const inputRef = useRef<TextInput>(null);

  return (
    <Pressable
      onPress={() => inputRef.current?.focus()}
      accessibilityRole="none"
      style={styles.row}>
      {Array.from({ length }).map((_, i) => {
        const char = value[i] ?? '';
        const active = i === value.length;
        return (
          <View key={i} style={[styles.box, (active || !!char) && styles.boxActive]}>
            <Text style={styles.char}>{char}</Text>
          </View>
        );
      })}

      <TextInput
        ref={inputRef}
        value={value}
        onChangeText={(t) => onChange(t.replace(/\D/g, '').slice(0, length))}
        keyboardType="number-pad"
        maxLength={length}
        autoFocus
        accessibilityLabel="Enter the verification code"
        style={styles.hidden}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: spacing.sm, justifyContent: 'center' },
  box: {
    width: 48,
    height: 56,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  boxActive: { borderColor: colors.primary, borderWidth: 2, backgroundColor: colors.bg },
  char: { fontFamily: fonts.bold, fontSize: 22, color: colors.text },
  hidden: { position: 'absolute', opacity: 0, width: 1, height: 1 },
});
