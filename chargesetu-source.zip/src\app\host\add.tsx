import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Button from '@/components/Button';
import { AMENITIES } from '@/data/amenities';
import { LOCALITIES } from '@/data/localities';
import { SOCKET_ORDER, SOCKETS } from '@/data/sockets';
import { DAY_LABELS, TIME_SLOTS } from '@/data/timeSlots';
import { repo } from '@/services';
import { useSession } from '@/store/useSession';
import { card, colors, fonts, HIT_TARGET, radius, spacing, type } from '@/theme';
import { AmenityId, Availability, SocketType, TimeSlotId } from '@/types';

const DAYS = [0, 1, 2, 3, 4, 5, 6] as const;

export default function AddChargingSpot() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const user = useSession((s) => s.user);

  const [title, setTitle] = useState(user ? `${user.name.split(' ')[0]}'s Charger` : '');
  const [area, setArea] = useState(LOCALITIES[0]);
  const [address, setAddress] = useState('');
  const [landmark, setLandmark] = useState('');
  const [socket, setSocket] = useState<SocketType>('SOCKET_15A');
  const [powerKw, setPowerKw] = useState('2.0');
  const [price, setPrice] = useState('9');
  const [grid, setGrid] = useState<Record<number, TimeSlotId[]>>({});
  const [amenities, setAmenities] = useState<AmenityId[]>(['ELECTRICITY_SOCKET']);
  const [busy, setBusy] = useState(false);

  const chooseSocket = (id: SocketType) => {
    setSocket(id);
    setPowerKw(String(SOCKETS[id].usableKw)); // auto-fill, still editable
  };

  const toggleSlot = (day: number, slot: TimeSlotId) =>
    setGrid((g) => {
      const current = g[day] ?? [];
      return {
        ...g,
        [day]: current.includes(slot) ? current.filter((s) => s !== slot) : [...current, slot],
      };
    });

  const toggleAmenity = (id: AmenityId) =>
    setAmenities((a) => (a.includes(id) ? a.filter((x) => x !== id) : [...a, id]));

  const slotCount = Object.values(grid).flat().length;

  const publish = async () => {
    if (!user) return;
    setBusy(true);
    try {
      const availability: Availability[] = DAYS.filter((d) => (grid[d] ?? []).length > 0).map((d) => ({
        day: d,
        slots: grid[d],
      }));

      await repo.createCharger({
        hostId: user.id,
        hostName: user.name.split(' ')[0] || 'Host',
        title: title.trim(),
        city: 'Indore',
        addressLine: address.trim() || area.name,
        landmark: landmark.trim(),
        geo: { lat: area.lat, lng: area.lng },
        socketType: socket,
        connectors: [],
        powerKw: Number(powerKw) || SOCKETS[socket].usableKw,
        pricePerKwh: Number(price) || 9,
        amenities,
        availability,
        photos: [],
        hostBadge: 'Newbie',
      });

      Alert.alert('Published', 'Your charging spot is now live on the map.', [
        { text: 'OK', onPress: () => router.replace('/') },
      ]);
    } catch (e) {
      Alert.alert('Could not publish', e instanceof Error ? e.message : 'Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.surface }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} accessibilityRole="button" accessibilityLabel="Go back" style={styles.iconBtn}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
        </Pressable>
        <Text style={[type.title, { flex: 1 }]}>Add your charging spot</Text>
      </View>

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
        <View style={styles.section}>
          <Text style={styles.label}>Listing title</Text>
          <TextInput style={styles.input} value={title} onChangeText={setTitle} placeholder="Ravi's Charger" placeholderTextColor={colors.textMuted} />

          <Text style={styles.label}>Area</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
            {LOCALITIES.map((l) => {
              const on = l.name === area.name;
              return (
                <Pressable
                  key={l.name}
                  onPress={() => setArea(l)}
                  accessibilityRole="button"
                  accessibilityState={{ selected: on }}
                  accessibilityLabel={l.name}
                  style={[styles.chip, on && styles.chipOn]}>
                  <Text style={[styles.chipText, on && styles.chipTextOn]}>{l.name}</Text>
                </Pressable>
              );
            })}
          </ScrollView>

          <Text style={styles.label}>Address line</Text>
          <TextInput style={styles.input} value={address} onChangeText={setAddress} placeholder="House / street" placeholderTextColor={colors.textMuted} />

          <Text style={styles.label}>Landmark</Text>
          <TextInput style={styles.input} value={landmark} onChangeText={setLandmark} placeholder="Near…" placeholderTextColor={colors.textMuted} />
        </View>

        <View style={styles.section}>
          <Text style={type.title}>Socket type</Text>
          {SOCKET_ORDER.map((id) => {
            const s = SOCKETS[id];
            const on = socket === id;
            return (
              <Pressable
                key={id}
                onPress={() => chooseSocket(id)}
                accessibilityRole="radio"
                accessibilityState={{ selected: on }}
                accessibilityLabel={s.label}
                style={[styles.socketCard, on && styles.socketCardOn]}>
                <View style={styles.rowBetween}>
                  <Text style={[type.title, { flex: 1 }]}>{s.label}</Text>
                  <MaterialCommunityIcons
                    name={on ? 'radiobox-marked' : 'radiobox-blank'}
                    size={22}
                    color={on ? colors.primary : colors.border}
                  />
                </View>
                <Text style={type.caption}>{s.realWorld}</Text>
              </Pressable>
            );
          })}

          <Text style={styles.label}>Power (kW)</Text>
          <TextInput
            style={styles.input}
            value={powerKw}
            onChangeText={(t) => setPowerKw(t.replace(/[^\d.]/g, ''))}
            keyboardType="decimal-pad"
          />

          <Text style={styles.label}>Price per kWh (₹)</Text>
          <TextInput
            style={styles.input}
            value={price}
            onChangeText={(t) => setPrice(t.replace(/[^\d.]/g, ''))}
            keyboardType="decimal-pad"
          />
          <Text style={styles.helper}>
            Domestic tariff is roughly ₹6–8/kWh — most hosts price between ₹8 and ₹12.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={type.title}>Weekly availability</Text>
          <Text style={type.caption}>Tap to toggle. {slotCount} slot{slotCount === 1 ? '' : 's'} selected.</Text>

          <View style={styles.gridHead}>
            <View style={styles.dayCol} />
            {TIME_SLOTS.map((s) => (
              <Text key={s.id} style={styles.gridHeadText}>
                {s.label.slice(0, 3)}
              </Text>
            ))}
          </View>

          {DAYS.map((d) => (
            <View key={d} style={styles.gridRow}>
              <Text style={[styles.dayCol, styles.dayText]}>{DAY_LABELS[d]}</Text>
              {TIME_SLOTS.map((s) => {
                const on = (grid[d] ?? []).includes(s.id);
                return (
                  <Pressable
                    key={s.id}
                    onPress={() => toggleSlot(d, s.id)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: on }}
                    accessibilityLabel={`${DAY_LABELS[d]} ${s.label}`}
                    style={[styles.cell, on && styles.cellOn]}>
                    {on && <MaterialCommunityIcons name="check" size={16} color={colors.white} />}
                  </Pressable>
                );
              })}
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={type.title}>Amenities</Text>
          <View style={styles.wrapRow}>
            {AMENITIES.map((a) => {
              const on = amenities.includes(a.id);
              return (
                <Pressable
                  key={a.id}
                  onPress={() => toggleAmenity(a.id)}
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: on }}
                  accessibilityLabel={a.label}
                  style={[styles.amenity, on && styles.amenityOn]}>
                  <MaterialCommunityIcons
                    name={a.icon as never}
                    size={16}
                    color={on ? colors.primaryDark : colors.textMuted}
                  />
                  <Text style={[styles.amenityText, on && { color: colors.primaryDark }]}>{a.label}</Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        <Button
          label="Publish listing"
          onPress={publish}
          loading={busy}
          disabled={!title.trim() || slotCount === 0}
          style={{ marginTop: spacing.lg }}
        />
        {slotCount === 0 && (
          <Text style={styles.helper}>Pick at least one availability slot before publishing.</Text>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.sm,
    backgroundColor: colors.bg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: { width: HIT_TARGET, height: HIT_TARGET, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, paddingBottom: spacing.xxxl, gap: spacing.lg },
  section: { ...card },
  label: { fontFamily: fonts.medium, fontSize: 13, color: colors.textMuted, marginTop: spacing.md, marginBottom: 4 },
  input: {
    minHeight: HIT_TARGET + 4,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.regular,
    fontSize: 16,
    color: colors.text,
  },
  helper: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMuted, marginTop: spacing.sm },
  chipRow: { gap: spacing.sm, paddingVertical: spacing.xs },
  chip: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontFamily: fonts.medium, fontSize: 13, color: colors.text },
  chipTextOn: { color: colors.white, fontFamily: fonts.semibold },
  socketCard: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  socketCardOn: { borderColor: colors.primary, borderWidth: 2, backgroundColor: colors.primarySoft },
  rowBetween: { flexDirection: 'row', alignItems: 'center' },
  gridHead: { flexDirection: 'row', alignItems: 'center', marginTop: spacing.md },
  gridHeadText: { flex: 1, textAlign: 'center', fontFamily: fonts.medium, fontSize: 11, color: colors.textMuted },
  gridRow: { flexDirection: 'row', alignItems: 'center', marginTop: spacing.sm },
  dayCol: { width: 40 },
  dayText: { fontFamily: fonts.medium, fontSize: 13, color: colors.text },
  cell: {
    flex: 1,
    height: 36,
    marginHorizontal: 3,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cellOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  wrapRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.md },
  amenity: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  amenityOn: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  amenityText: { fontFamily: fonts.medium, fontSize: 12, color: colors.textMuted },
});
